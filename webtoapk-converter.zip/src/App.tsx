import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { AppBuilderForm } from './components/AppBuilderForm';
import { DeviceSimulator } from './components/DeviceSimulator';
import { CentralAdsManager } from './components/CentralAdsManager';
import { MyAppsList } from './components/MyAppsList';
import { BuildGuideModal } from './components/BuildGuideModal';
import { AdGateModal } from './components/AdGateModal';
import { WebsiteAdBanner } from './components/WebsiteAdBanner';
import { AppConfig, AdConfig } from './types/app';
import { storage, defaultGlobalAds } from './services/storage';
import { generateAndroidProjectZip } from './services/zipGenerator';
import { generateDirectApkFile } from './services/apkGenerator';
import { Check, Sparkles, AlertCircle, Download, FileCode, CheckCircle2, X, Smartphone, ArrowRight, ExternalLink, BookOpen } from 'lucide-react';

export default function App() {
  const [apps, setApps] = useState<AppConfig[]>([]);
  const [currentApp, setCurrentApp] = useState<AppConfig | null>(null);
  const [globalAds, setGlobalAds] = useState<AdConfig>(defaultGlobalAds);
  const [activeTab, setActiveTab] = useState<'builder' | 'my-apps' | 'ads-manager' | 'guide'>('builder');
  const [isGeneratingApk, setIsGeneratingApk] = useState(false);
  const [isGeneratingZip, setIsGeneratingZip] = useState(false);
  const [downloadNotice, setDownloadNotice] = useState<string | null>(null);
  
  // AdGate state (Mandatory Adsterra ad before download)
  const [adGateState, setAdGateState] = useState<{
    isOpen: boolean;
    pendingApp: AppConfig | null;
    targetType: 'apk' | 'zip';
  }>({
    isOpen: false,
    pendingApp: null,
    targetType: 'apk',
  });

  const [apkBuildModal, setApkBuildModal] = useState<{
    show: boolean;
    step: number;
    appName: string;
    fileName: string;
    downloadUrl: string | null;
  }>({
    show: false,
    step: 0,
    appName: '',
    fileName: '',
    downloadUrl: null,
  });

  // Load apps on mount
  useEffect(() => {
    const loadedApps = storage.getApps();
    const loadedAds = storage.getGlobalAds();
    setApps(loadedApps);
    setGlobalAds(loadedAds);
    if (loadedApps.length > 0) {
      setCurrentApp(loadedApps[0]);
    }
  }, []);

  const handleRefreshApps = () => {
    const updated = storage.getApps();
    setApps(updated);
    if (currentApp) {
      const refreshed = updated.find((a) => a.id === currentApp.id);
      if (refreshed) {
        setCurrentApp(refreshed);
      }
    }
  };

  const handleUpdateApp = (updated: AppConfig) => {
    setCurrentApp(updated);
  };

  const handleSaveAndPreview = (app: AppConfig) => {
    storage.saveApp(app);
    handleRefreshApps();
    setDownloadNotice(`Changes saved! Live Android Simulator updated for ${app.name}.`);
    setTimeout(() => setDownloadNotice(null), 3000);
  };

  const handleUpdateGlobalAds = (updatedAds: AdConfig) => {
    setGlobalAds(updatedAds);
    storage.saveGlobalAds(updatedAds, true);
    handleRefreshApps();
  };

  // Intercept APK download with AdGate if required
  const requestDownloadDirectApk = (app: AppConfig) => {
    if (globalAds.adsterra?.enabled && globalAds.adsterra?.forceAdBeforeDownload) {
      setAdGateState({
        isOpen: true,
        pendingApp: app,
        targetType: 'apk',
      });
    } else {
      executeDownloadDirectApk(app);
    }
  };

  // Intercept ZIP download with AdGate if required
  const requestDownloadZip = (app: AppConfig) => {
    if (globalAds.adsterra?.enabled && globalAds.adsterra?.forceAdBeforeDownload) {
      setAdGateState({
        isOpen: true,
        pendingApp: app,
        targetType: 'zip',
      });
    } else {
      executeDownloadZip(app);
    }
  };

  const handleAdGateCompleted = () => {
    const { pendingApp, targetType } = adGateState;
    setAdGateState({ isOpen: false, pendingApp: null, targetType: 'apk' });
    if (pendingApp) {
      if (targetType === 'apk') {
        executeDownloadDirectApk(pendingApp);
      } else {
        executeDownloadZip(pendingApp);
      }
    }
  };

  // 1. DIRECT .APK FILE GENERATOR (URL to .APK)
  const executeDownloadDirectApk = async (app: AppConfig) => {
    const cleanFileName = (app.name || 'AndroidApp').replace(/[^a-zA-Z0-9_-]/g, '_');
    const apkFileName = `${cleanFileName}.apk`;

    try {
      setIsGeneratingApk(true);
      setApkBuildModal({
        show: true,
        step: 1,
        appName: app.name,
        fileName: apkFileName,
        downloadUrl: null,
      });

      // Simulation steps for user visual feedback
      await new Promise((r) => setTimeout(r, 600));
      setApkBuildModal((prev) => ({ ...prev, step: 2 }));

      await new Promise((r) => setTimeout(r, 700));
      setApkBuildModal((prev) => ({ ...prev, step: 3 }));

      // Generate the binary .apk package with Adsterra integration
      const apkBlob = await generateDirectApkFile(app);
      const downloadUrl = URL.createObjectURL(apkBlob);

      await new Promise((r) => setTimeout(r, 600));
      setApkBuildModal((prev) => ({ ...prev, step: 4, downloadUrl }));

      // Automatically trigger file download with .apk extension
      const a = document.createElement('a');
      a.href = downloadUrl;
      a.download = apkFileName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      setDownloadNotice(
        `Mubarak ho! "${apkFileName}" direct APK file download ho gayi hai! Isme Adsterra Ads aur Live Cloud sync shamil hai.`
      );
      setTimeout(() => setDownloadNotice(null), 7000);
    } catch (error) {
      console.error('Error generating direct APK:', error);
      alert('Error creating APK file. Please try again.');
    } finally {
      setIsGeneratingApk(false);
    }
  };

  // 2. FULL SOURCE CODE PROJECT ZIP
  const executeDownloadZip = async (app: AppConfig) => {
    try {
      setIsGeneratingZip(true);
      const zipBlob = await generateAndroidProjectZip(app);
      const downloadUrl = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = downloadUrl;
      const cleanFileName = (app.name || 'AndroidApp').replace(/[^a-zA-Z0-9_-]/g, '_');
      a.download = `${cleanFileName}_Android_Project.zip`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(downloadUrl);

      setDownloadNotice(
        `Android Studio Project ZIP "${cleanFileName}_Android_Project.zip" download ho gaya hai.`
      );
      setTimeout(() => setDownloadNotice(null), 6000);
    } catch (error) {
      console.error('Error generating project ZIP:', error);
      alert('Error creating ZIP package. Please try again.');
    } finally {
      setIsGeneratingZip(false);
    }
  };

  const handleCreateNewApp = () => {
    const newId = `app_${Date.now()}`;
    const newApp: AppConfig = {
      id: newId,
      name: 'My New App',
      packageName: `com.studyhai.app${Math.floor(Math.random() * 899 + 100)}`,
      versionName: '1.0.0',
      versionCode: 1,
      url: 'https://wikipedia.org',
      iconDataUrl: '',
      themeColor: '#4f46e5',
      splashBgColor: '#0f172a',
      splashDurationMs: 1500,
      pullToRefresh: true,
      showNavigationControls: true,
      zoomControls: false,
      offlineSupport: true,
      enableDownloadManager: true,
      enableFileUploads: true,
      permissions: {
        internet: true,
        camera: true,
        storage: true,
        geolocation: true,
        notifications: true,
        microphone: false,
      },
      remoteSync: {
        syncEnabled: true,
        currentUrl: 'https://wikipedia.org',
        maintenanceMode: false,
        maintenanceMessage: 'App under routine maintenance.',
        announcement: {
          enabled: false,
          id: '',
          text: '',
          type: 'info',
        },
        ads: { ...globalAds },
        lastSyncedAt: new Date().toISOString(),
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    storage.saveApp(newApp);
    handleRefreshApps();
    setCurrentApp(newApp);
    setActiveTab('builder');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar adhering to the 3-zone contract */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        appsCount={apps.length}
        onNewApp={handleCreateNewApp}
      />

      {/* Website-Level Adsterra Sponsored Banner */}
      <WebsiteAdBanner adsterra={globalAds.adsterra} />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-4">
        {/* Floating Download Success Notification */}
        {downloadNotice && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center justify-between gap-3 shadow-lg animate-fade-in">
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5 text-emerald-400 shrink-0" />
              <span>{downloadNotice}</span>
            </div>
            <button
              onClick={() => setDownloadNotice(null)}
              className="text-emerald-400 hover:text-white text-xs font-semibold cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {/* Tab View Switcher */}
        {activeTab === 'ads-manager' ? (
          <CentralAdsManager
            globalAds={globalAds}
            onUpdateGlobalAds={handleUpdateGlobalAds}
            apps={apps}
            onSelectAppForPreview={(selected) => {
              setCurrentApp(selected);
              setActiveTab('builder');
            }}
          />
        ) : activeTab === 'my-apps' ? (
          <MyAppsList
            apps={apps}
            onSelectAppForPreview={(selected) => {
              setCurrentApp(selected);
              setActiveTab('builder');
            }}
            onDownloadDirectApk={requestDownloadDirectApk}
            onDownloadZip={requestDownloadZip}
            onNewApp={handleCreateNewApp}
            onRefreshApps={handleRefreshApps}
          />
        ) : activeTab === 'guide' ? (
          <BuildGuideModal />
        ) : (
          /* Main 2-Column Converter & Simulator Split */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Form & Configuration */}
            <div className="lg:col-span-7 xl:col-span-8">
              {currentApp && (
                <AppBuilderForm
                  currentApp={currentApp}
                  onUpdateApp={handleUpdateApp}
                  onSaveAndPreview={handleSaveAndPreview}
                  onDownloadDirectApk={requestDownloadDirectApk}
                  onGenerateZip={requestDownloadZip}
                  isGeneratingApk={isGeneratingApk}
                  isGeneratingZip={isGeneratingZip}
                />
              )}
            </div>

            {/* Right Column: Live Android Device Simulator */}
            <div className="lg:col-span-5 xl:col-span-4 sticky top-24">
              {currentApp ? (
                <DeviceSimulator
                  app={currentApp}
                  onDownloadDirectApk={() => requestDownloadDirectApk(currentApp)}
                  onDownloadZip={() => requestDownloadZip(currentApp)}
                  isDownloadingApk={isGeneratingApk}
                  isDownloadingZip={isGeneratingZip}
                />
              ) : (
                <div className="p-8 text-center bg-slate-900 border border-slate-800 rounded-2xl">
                  <p className="text-xs text-slate-400">No app loaded in simulator.</p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {/* Mandatory Adsterra Ad Gate Modal (Triggered before APK download) */}
      {currentApp && (
        <AdGateModal
          app={adGateState.pendingApp || currentApp}
          adsterra={globalAds.adsterra}
          isOpen={adGateState.isOpen}
          onAdCompleted={handleAdGateCompleted}
          onClose={() => setAdGateState({ isOpen: false, pendingApp: null, targetType: 'apk' })}
        />
      )}

      {/* APK Compilation Progress & Success Modal */}
      {apkBuildModal.show && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 shadow-2xl text-center relative overflow-hidden">
            {/* Close Button */}
            <button
              onClick={() => setApkBuildModal((prev) => ({ ...prev, show: false }))}
              className="absolute top-4 right-4 text-slate-400 hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {apkBuildModal.step < 4 ? (
              <div>
                <div className="w-14 h-14 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center mx-auto mb-4 text-indigo-400">
                  <Smartphone className="w-7 h-7 animate-pulse" />
                </div>

                <h3 className="text-base font-bold text-white mb-1">
                  Converting URL to Android APK...
                </h3>
                <p className="text-xs text-slate-400 mb-6">
                  {apkBuildModal.appName} ke liye direct <code className="text-emerald-400 font-mono">.apk</code> file compile ho rahi hai.
                </p>

                {/* Progress Checklist */}
                <div className="space-y-3 text-left mb-6 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                  <div className="flex items-center gap-2.5 text-xs">
                    {apkBuildModal.step >= 1 ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-slate-600 shrink-0" />
                    )}
                    <span className={apkBuildModal.step >= 1 ? 'text-white font-medium' : 'text-slate-500'}>
                      Target URL & WebView Client setup
                    </span>
                  </div>

                  <div className="flex items-center gap-2.5 text-xs">
                    {apkBuildModal.step >= 2 ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-slate-600 shrink-0" />
                    )}
                    <span className={apkBuildModal.step >= 2 ? 'text-white font-medium' : 'text-slate-500'}>
                      Adsterra Network & Cloud Sync injection
                    </span>
                  </div>

                  <div className="flex items-center gap-2.5 text-xs">
                    {apkBuildModal.step >= 3 ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <div className="w-4 h-4 rounded-full border border-slate-600 shrink-0" />
                    )}
                    <span className={apkBuildModal.step >= 3 ? 'text-white font-medium' : 'text-slate-500'}>
                      Compiling DEX & Android Package (.apk) signature
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4 text-emerald-400">
                  <Check className="w-7 h-7" />
                </div>

                <h3 className="text-base font-bold text-white mb-1">
                  APK Successfully Generated!
                </h3>
                <p className="text-xs text-slate-400 mb-4">
                  Aapka <code className="text-emerald-400 font-mono font-bold">{apkBuildModal.fileName}</code> download ho chuka hai!
                </p>

                {/* Troubleshooting for Parse Error */}
                <div className="bg-amber-950/40 border border-amber-500/50 rounded-2xl p-4 text-left mb-4 shadow-md">
                  <div className="flex items-center gap-2 text-amber-300 font-bold text-xs mb-1.5">
                    <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Phone me "There was a problem parsing the package" error?</span>
                  </div>
                  <p className="text-[11px] text-amber-200/90 leading-relaxed mb-3">
                    Android phone security official Google SDK se compiled Dalvik binary bytecode mangti hai. Agar aapke phone me install karte waqt <strong>Parse Error</strong> aaye, toh <strong>Project (ZIP)</strong> download karein aur included GitHub Actions se 1-minute me official 100% installable APK banayein!
                  </p>
                  <div className="flex flex-col sm:flex-row gap-2">
                    <button
                      onClick={() => {
                        if (currentApp) {
                          executeDownloadZip(currentApp);
                        }
                      }}
                      className="flex-1 py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                    >
                      <FileCode className="w-3.5 h-3.5" />
                      <span>Download Project (ZIP)</span>
                    </button>
                    <button
                      onClick={() => {
                        setApkBuildModal((prev) => ({ ...prev, show: false }));
                        setActiveTab('guide');
                      }}
                      className="flex-1 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-indigo-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>1-Min GitHub Guide Dekhein</span>
                    </button>
                  </div>
                </div>

                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 text-left mb-5">
                  <p className="text-xs font-bold text-white mb-2 flex items-center gap-1.5">
                    <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Android Phone me Install Kaise Karein:</span>
                  </p>
                  <ol className="text-[11px] text-slate-300 space-y-1.5 list-decimal pl-4">
                    <li>Downloaded <code className="text-emerald-400 font-mono">.apk</code> file par tap karein.</li>
                    <li>Agar "Install Unknown Apps" aaye toh <strong>Settings &gt; Allow from this source</strong> ON kar dein.</li>
                    <li><strong>Install</strong> button dabayein — aapka website app khul jayega!</li>
                    <li>Website se jo bhi Adsterra Ads aur URL badlenge, is APK me automatically sync honge!</li>
                  </ol>
                </div>

                <div className="flex flex-col gap-2">
                  {apkBuildModal.downloadUrl && (
                    <a
                      href={apkBuildModal.downloadUrl}
                      download={apkBuildModal.fileName}
                      className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30"
                    >
                      <Download className="w-4 h-4" />
                      <span>Download .APK Again</span>
                    </a>
                  )}

                  <button
                    onClick={() => setApkBuildModal((prev) => ({ ...prev, show: false }))}
                    className="w-full py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>WebToAPK Studio · Direct .APK Generator with Adsterra & Central Cloud Sync</p>
          <div className="flex items-center gap-4 text-[11px] text-slate-400">
            <span className="text-amber-400 font-semibold">Adsterra Ads Enabled</span>
            <span>·</span>
            <span>Direct .apk Download</span>
            <span>·</span>
            <span>Android 14 (API 34)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
