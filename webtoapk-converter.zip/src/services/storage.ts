import { AppConfig, AdConfig } from '../types/app';

const APPS_STORAGE_KEY = 'webtoapk_apps_v1';
const GLOBAL_ADS_STORAGE_KEY = 'webtoapk_global_ads_v1';

export const defaultGlobalAds: AdConfig = {
  enabled: true,
  provider: 'adsterra',
  adsterra: {
    enabled: true,
    directLink: 'https://brijmohan.org/14/cafb0759f6d8b8f39a687b5e274490bc',
    bannerZoneKey: 'b35d45c32cd9d5ff4ec792d306d75bad',
    bannerScriptUrl: 'https://brijmohan.org/22/b35d45c32cd9d5ff4ec792d306d75bad',
    socialBarScript: 'https://brijmohan.org/14/cafb0759f6d8b8f39a687b5e274490bc',
    popunderUrl: 'https://brijmohan.org/21/d71f777e57bd92b4e6249ad7e7bc8fa0',
    forceAdBeforeDownload: true,
    countdownSeconds: 5,
  },
  bannerAd: {
    enabled: true,
    position: 'bottom',
    customBanner: {
      title: 'Adsterra Sponsored Network',
      description: 'Tap to visit high-converting partner offers and rewards.',
      imageUrl: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=100&auto=format&fit=crop&q=80',
      ctaText: 'Visit Partner',
      targetUrl: 'https://www.profitablecpmrate.com/d87f91a92e104',
      bgColor: '#1e1b4b',
      textColor: '#ffffff',
    },
    admobUnitId: 'ca-app-pub-3940256099942544/6300978111', // Google Test Ad Unit
  },
  interstitialAd: {
    enabled: true,
    intervalMinutes: 3,
    triggerOnPages: 3,
    customInterstitial: {
      title: 'Adsterra Special Sponsored Offer',
      description: 'Download our top recommended partner apps and claim instant rewards.',
      imageUrl: 'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=600&auto=format&fit=crop&q=80',
      ctaText: 'Claim Offer',
      targetUrl: 'https://www.profitablecpmrate.com/d87f91a92e104',
    },
    admobUnitId: 'ca-app-pub-3940256099942544/1033173712', // Google Test Interstitial
  },
};

const initialApps: AppConfig[] = [
  {
    id: 'app_store_9021',
    name: 'Smart Mart Online',
    packageName: 'com.studyhai.smartmart',
    versionName: '1.0.0',
    versionCode: 1,
    url: 'https://wikipedia.org',
    iconDataUrl: '',
    themeColor: '#4f46e5',
    splashBgColor: '#0f172a',
    splashDurationMs: 1500,
    pullToRefresh: true,
    showNavigationControls: true,
    zoomControls: false,
    offlineSupport: true,
    enableDownloadManager: true,
    enableFileUploads: true,
    permissions: {
      internet: true,
      camera: true,
      storage: true,
      geolocation: true,
      notifications: true,
      microphone: false,
    },
    remoteSync: {
      syncEnabled: true,
      currentUrl: 'https://wikipedia.org',
      maintenanceMode: false,
      maintenanceMessage: 'App is temporarily under maintenance for server upgrade. Please check back shortly.',
      announcement: {
        enabled: true,
        id: 'ann_welcome',
        text: 'Welcome to Smart Mart! Free shipping on all orders today.',
        actionUrl: 'https://wikipedia.org',
        type: 'promo',
      },
      ads: { ...defaultGlobalAds },
      lastSyncedAt: new Date().toISOString(),
    },
    createdAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'app_news_4412',
    name: 'Bharat Daily News',
    packageName: 'com.studyhai.bharatnews',
    versionName: '1.0.2',
    versionCode: 2,
    url: 'https://bbc.com',
    iconDataUrl: '',
    themeColor: '#e11d48',
    splashBgColor: '#881337',
    splashDurationMs: 1200,
    pullToRefresh: true,
    showNavigationControls: false,
    zoomControls: true,
    offlineSupport: true,
    enableDownloadManager: true,
    enableFileUploads: false,
    permissions: {
      internet: true,
      camera: false,
      storage: true,
      geolocation: false,
      notifications: true,
      microphone: false,
    },
    remoteSync: {
      syncEnabled: true,
      currentUrl: 'https://bbc.com',
      maintenanceMode: false,
      maintenanceMessage: 'News server maintenance in progress.',
      announcement: {
        enabled: false,
        id: '',
        text: '',
        type: 'info',
      },
      ads: { ...defaultGlobalAds },
      lastSyncedAt: new Date().toISOString(),
    },
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export const storage = {
  getApps(): AppConfig[] {
    try {
      const data = localStorage.getItem(APPS_STORAGE_KEY);
      if (!data) {
        localStorage.setItem(APPS_STORAGE_KEY, JSON.stringify(initialApps));
        return initialApps;
      }
      const rawApps: AppConfig[] = JSON.parse(data);
      // Ensure all loaded apps have complete ads and adsterra structures
      return rawApps.map((app) => ({
        ...app,
        remoteSync: {
          ...app.remoteSync,
          ads: {
            ...defaultGlobalAds,
            ...(app.remoteSync?.ads || {}),
            adsterra: {
              ...defaultGlobalAds.adsterra,
              ...(app.remoteSync?.ads?.adsterra || {}),
            },
          },
        },
      }));
    } catch {
      return initialApps;
    }
  },

  saveApps(apps: AppConfig[]): void {
    try {
      localStorage.setItem(APPS_STORAGE_KEY, JSON.stringify(apps));
    } catch (e) {
      console.error('Failed to save apps to storage', e);
    }
  },

  getApp(id: string): AppConfig | undefined {
    const apps = this.getApps();
    return apps.find((a) => a.id === id);
  },

  saveApp(app: AppConfig): void {
    const apps = this.getApps();
    const index = apps.findIndex((a) => a.id === app.id);
    if (index >= 0) {
      apps[index] = { ...app, updatedAt: new Date().toISOString() };
    } else {
      apps.unshift(app);
    }
    this.saveApps(apps);
  },

  deleteApp(id: string): void {
    const apps = this.getApps().filter((a) => a.id !== id);
    this.saveApps(apps);
  },

  getGlobalAds(): AdConfig {
    try {
      const data = localStorage.getItem(GLOBAL_ADS_STORAGE_KEY);
      if (!data) {
        localStorage.setItem(GLOBAL_ADS_STORAGE_KEY, JSON.stringify(defaultGlobalAds));
        return defaultGlobalAds;
      }
      const parsed = JSON.parse(data);
      return {
        ...defaultGlobalAds,
        ...parsed,
        adsterra: {
          ...defaultGlobalAds.adsterra,
          ...(parsed?.adsterra || {}),
        },
        bannerAd: {
          ...defaultGlobalAds.bannerAd,
          ...(parsed?.bannerAd || {}),
          customBanner: {
            ...defaultGlobalAds.bannerAd.customBanner,
            ...(parsed?.bannerAd?.customBanner || {}),
          },
        },
        interstitialAd: {
          ...defaultGlobalAds.interstitialAd,
          ...(parsed?.interstitialAd || {}),
          customInterstitial: {
            ...defaultGlobalAds.interstitialAd.customInterstitial,
            ...(parsed?.interstitialAd?.customInterstitial || {}),
          },
        },
      };
    } catch {
      return defaultGlobalAds;
    }
  },

  saveGlobalAds(ads: AdConfig, syncToAllApps = true): void {
    try {
      localStorage.setItem(GLOBAL_ADS_STORAGE_KEY, JSON.stringify(ads));
      if (syncToAllApps) {
        const apps = this.getApps();
        const updated = apps.map((app) => ({
          ...app,
          remoteSync: {
            ...app.remoteSync,
            ads: { ...ads },
            lastSyncedAt: new Date().toISOString(),
          },
          updatedAt: new Date().toISOString(),
        }));
        this.saveApps(updated);
      }
    } catch (e) {
      console.error('Failed to save global ads', e);
    }
  },
};
