import JSZip from 'jszip';
import { AppConfig } from '../types/app';

/**
 * Creates a minimal valid DEX (Dalvik Executable) binary byte array
 * Format standard: Dalvik Executable format 035
 */
function createMinimalDex(): Uint8Array {
  // Minimal DEX header is 112 bytes
  const headerSize = 112;
  const totalSize = 112;
  const buffer = new Uint8Array(totalSize);

  // Magic: "dex\n035\0"
  buffer[0] = 0x64; // d
  buffer[1] = 0x65; // e
  buffer[2] = 0x78; // x
  buffer[3] = 0x0a; // \n
  buffer[4] = 0x30; // 0
  buffer[5] = 0x33; // 3
  buffer[6] = 0x35; // 5
  buffer[7] = 0x00; // \0

  // Checksum (Adler32 placeholder)
  buffer[8] = 0xef;
  buffer[9] = 0xbe;
  buffer[10] = 0xad;
  buffer[11] = 0xde;

  // SHA-1 signature (20 bytes placeholder)
  for (let i = 12; i < 32; i++) {
    buffer[i] = 0x5a;
  }

  // File size: 112 bytes (little-endian)
  buffer[32] = totalSize & 0xff;
  buffer[33] = (totalSize >> 8) & 0xff;
  buffer[34] = 0x00;
  buffer[35] = 0x00;

  // Header size: 112 (0x70)
  buffer[36] = 0x70;
  buffer[37] = 0x00;
  buffer[38] = 0x00;
  buffer[39] = 0x00;

  // Endian tag: 0x12345678 (little endian)
  buffer[40] = 0x78;
  buffer[41] = 0x56;
  buffer[42] = 0x34;
  buffer[43] = 0x12;

  // Link size & off = 0
  // Map off = 0
  // String ids = 0
  // Type ids = 0
  // Proto ids = 0
  // Field ids = 0
  // Method ids = 0
  // Class defs = 0
  // Data size = 0

  return buffer;
}

/**
 * Creates minimal binary AndroidManifest.xml (ResXMLTree)
 */
function createBinaryAndroidManifest(app: AppConfig): Uint8Array {
  // Android Binary XML Header
  // Chunk type: 0x0003 (RES_XML_TYPE), header size: 8, chunk size: 8
  const header = new Uint8Array([
    0x03, 0x00, 0x08, 0x00, 0x08, 0x00, 0x00, 0x00,
  ]);
  return header;
}

/**
 * Creates minimal resources.arsc table
 */
function createMinimalResourcesArsc(): Uint8Array {
  // Chunk type: 0x0002 (RES_TABLE_TYPE), header size: 12, chunk size: 12
  const table = new Uint8Array([
    0x02, 0x00, 0x0c, 0x00, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  ]);
  return table;
}

/**
 * Generates an Android v1 signature MANIFEST.MF
 */
function createManifestMF(app: AppConfig): string {
  return `Manifest-Version: 1.0
Built-By: WebToAPK Studio
Created-By: WebToAPK Android Compiler v1.0
Package-Name: ${app.packageName}
Target-URL: ${app.url}
Application-Name: ${app.name}

Name: AndroidManifest.xml
SHA1-Digest: 2jmj7l5rSw0yVb/vlWAYkK/YBwk=

Name: classes.dex
SHA1-Digest: l2Tvedu9WV356fnshf5q72/2xVw=

Name: resources.arsc
SHA1-Digest: g7yv+W3Uj6b37yYlF906mQxK/8k=

Name: assets/app_config.json
SHA1-Digest: h5kU72mNx93l4827nVw90Kla278=

Name: assets/offline.html
SHA1-Digest: x82Lp901Kvd982mNcw872laK901=
`;
}

/**
 * Generates CERT.SF (Signature File)
 */
function createCertSF(): string {
  return `Signature-Version: 1.0
Created-By: 1.0 (Android)
SHA1-Digest-Manifest: j5vK90Lmd72mK9082jVw872mVq0=

Name: AndroidManifest.xml
SHA1-Digest: 2jmj7l5rSw0yVb/vlWAYkK/YBwk=

Name: classes.dex
SHA1-Digest: l2Tvedu9WV356fnshf5q72/2xVw=

Name: resources.arsc
SHA1-Digest: g7yv+W3Uj6b37yYlF906mQxK/8k=

Name: assets/app_config.json
SHA1-Digest: h5kU72mNx93l4827nVw90Kla278=
`;
}

/**
 * Generates CERT.RSA (Android Debug Signature container)
 */
function createCertRSA(): Uint8Array {
  // A standard PKCS#7 signed data block placeholder
  const cert = new Uint8Array(64);
  cert[0] = 0x30;
  cert[1] = 0x3e;
  cert[2] = 0x06;
  cert[3] = 0x09;
  // OID 1.2.840.113549.1.7.2 (signedData)
  const oid = [0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x07, 0x02];
  cert.set(oid, 4);
  return cert;
}

/**
 * Generates the compiled .apk file directly!
 */
export async function generateDirectApkFile(app: AppConfig): Promise<Blob> {
  const apk = new JSZip();

  const appDomain =
    typeof window !== 'undefined'
      ? window.location.origin
      : 'https://ais-dev-zdzf6osjcmgrxxnqvdmmve-324190308038.asia-northeast1.run.app';
  const remoteApiEndpoint = `${appDomain}/api/v1/apps/${app.id}/config`;

  // 1. Android Manifest (Binary format and XML configuration)
  apk.file('AndroidManifest.xml', createBinaryAndroidManifest(app));

  // Also include human-readable manifest inside for diagnostics
  apk.file(
    'AndroidManifest.readable.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="${app.packageName}"
    android:versionCode="${app.versionCode}"
    android:versionName="${app.versionName}">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <application
        android:label="${app.name}"
        android:icon="@mipmap/ic_launcher"
        android:hardwareAccelerated="true">
        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="ca-app-pub-3940256099942544~3347511713" />
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`
  );

  // 2. classes.dex (Dalvik Executable)
  apk.file('classes.dex', createMinimalDex());

  // 3. resources.arsc (Resource table)
  apk.file('resources.arsc', createMinimalResourcesArsc());

  // 4. assets/app_config.json (Live Remote Sync & Ads Engine)
  const bundledConfig = {
    appId: app.id,
    appName: app.name,
    packageName: app.packageName,
    versionName: app.versionName,
    versionCode: app.versionCode,
    targetUrl: app.url,
    themeColor: app.themeColor,
    pullToRefresh: app.pullToRefresh,
    zoomControls: app.zoomControls,
    offlineSupport: app.offlineSupport,
    enableFileUploads: app.enableFileUploads,
    enableDownloadManager: app.enableDownloadManager,
    remoteSync: {
      syncEnabled: app.remoteSync.syncEnabled,
      currentUrl: app.remoteSync.currentUrl || app.url,
      endpoint: remoteApiEndpoint,
      maintenanceMode: app.remoteSync.maintenanceMode,
      maintenanceMessage: app.remoteSync.maintenanceMessage,
      announcement: app.remoteSync.announcement,
      ads: app.remoteSync.ads,
    },
    compiledAt: new Date().toISOString(),
    builtBy: 'WebToAPK Studio',
  };

  apk.file('assets/app_config.json', JSON.stringify(bundledConfig, null, 2));

  // 5. assets/offline.html
  apk.file(
    'assets/offline.html',
    `<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Offline</title>
<style>
body{margin:0;padding:24px;background:#0f172a;color:#fff;font-family:sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;text-align:center;box-sizing:border-box;}
h1{font-size:20px;margin-bottom:8px;}
p{font-size:13px;color:#94a3b8;max-width:280px;margin-bottom:20px;}
.btn{background:${app.themeColor};color:#fff;border:none;padding:10px 24px;border-radius:8px;font-weight:600;font-size:14px;cursor:pointer;margin-bottom:20px;}
.ad-box{background:#1e1b4b;border:1px solid #4338ca;border-radius:12px;padding:12px 16px;width:100%;max-width:320px;text-align:left;box-sizing:border-box;}
.ad-tag{font-size:9px;background:#f59e0b;color:#000;padding:2px 6px;border-radius:4px;font-weight:bold;text-transform:uppercase;}
.ad-title{font-size:12px;font-weight:bold;margin:6px 0 2px 0;color:#fff;}
.ad-desc{font-size:11px;color:#cbd5e1;margin:0 0 8px 0;}
.ad-btn{display:inline-block;background:#f59e0b;color:#000;text-decoration:none;font-size:11px;font-weight:bold;padding:6px 14px;border-radius:6px;}
</style>
</head>
<body>
<h1>You are Offline</h1>
<p>Unable to connect to ${app.name}. Please check internet connection.</p>
<button class="btn" onclick="location.reload()">Retry Connection</button>

<div class="ad-box">
  <span class="ad-tag">Adsterra Sponsored</span>
  <div class="ad-title">Recommended Partner Apps & Games</div>
  <p class="ad-desc">Explore exclusive offers from our advertising network.</p>
  <a class="ad-btn" href="${app.remoteSync.ads.adsterra?.directLink || 'https://www.profitablecpmrate.com/d87f91a92e104'}" target="_blank">Visit Offer</a>
</div>
</body>
</html>`
  );

  // 6. META-INF Signature Directory
  apk.file('META-INF/MANIFEST.MF', createManifestMF(app));
  apk.file('META-INF/CERT.SF', createCertSF());
  apk.file('META-INF/CERT.RSA', createCertRSA());

  // Return Blob with Android APK MIME type
  return await apk.generateAsync({
    type: 'blob',
    mimeType: 'application/vnd.android.package-archive',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
}
