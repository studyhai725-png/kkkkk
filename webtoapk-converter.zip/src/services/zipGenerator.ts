import JSZip from 'jszip';
import { AppConfig } from '../types/app';

export async function generateAndroidProjectZip(app: AppConfig): Promise<Blob> {
  const zip = new JSZip();

  // Clean package path (e.g. com.studyhai.app -> com/studyhai/app)
  const packageParts = app.packageName.split('.');
  const packageDir = packageParts.join('/');
  const appDomain = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-zdzf6osjcmgrxxnqvdmmve-324190308038.asia-northeast1.run.app';
  const remoteApiEndpoint = `${appDomain}/api/v1/apps/${app.id}/config`;

  // 1. Root files
  zip.file(
    'build.gradle.kts',
    `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.android) apply false
}
`
  );

  zip.file(
    'settings.gradle.kts',
    `pluginManagement {
    repositories {
        google {
            content {
                includeGroupByRegex("com\\\\.android.*")
                includeGroupByRegex("com\\\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "${app.name.replace(/[^a-zA-Z0-9_]/g, '')}"
include(":app")
`
  );

  zip.file(
    'gradle.properties',
    `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`
  );

  // Gradle version catalog
  zip.file(
    'gradle/libs.versions.toml',
    `[versions]
agp = "8.3.1"
kotlin = "1.9.22"
coreKtx = "1.12.0"
appcompat = "1.6.1"
material = "1.11.0"
constraintlayout = "2.1.4"
swiperefreshlayout = "1.1.0"
webkit = "1.10.0"
playServicesAds = "23.0.0"
okhttp = "4.12.0"
gson = "2.10.1"
coroutines = "1.7.3"

[libraries]
androidx-core-ktx = { group = "androidx.core", name = "core-ktx", version.ref = "coreKtx" }
androidx-appcompat = { group = "androidx.appcompat", name = "appcompat", version.ref = "appcompat" }
material = { group = "com.google.android.material", name = "material", version.ref = "material" }
androidx-constraintlayout = { group = "androidx.constraintlayout", name = "constraintlayout", version.ref = "constraintlayout" }
androidx-swiperefreshlayout = { group = "androidx.swiperefreshlayout", name = "swiperefreshlayout", version.ref = "swiperefreshlayout" }
androidx-webkit = { group = "androidx.webkit", name = "webkit", version.ref = "webkit" }
play-services-ads = { group = "com.google.android.gms", name = "play-services-ads", version.ref = "playServicesAds" }
okhttp = { group = "com.squareup.okhttp3", name = "okhttp", version.ref = "okhttp" }
gson = { group = "com.google.code.gson", name = "gson", version.ref = "gson" }
kotlinx-coroutines-android = { group = "org.jetbrains.kotlinx", name = "kotlinx-coroutines-android", version.ref = "coroutines" }

[plugins]
android-application = { id = "com.android.application", version.ref = "agp" }
kotlin-android = { id = "org.jetbrains.kotlin.android", version.ref = "kotlin" }
`
  );

  zip.file(
    'gradle/wrapper/gradle-wrapper.properties',
    `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
  );

  // 2. app/build.gradle.kts
  zip.file(
    'app/build.gradle.kts',
    `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "${app.packageName}"
    compileSdk = 34

    defaultConfig {
        applicationId = "${app.packageName}"
        minSdk = 24
        targetSdk = 34
        versionCode = ${app.versionCode}
        versionName = "${app.versionName}"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        
        manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713" // Google Test App ID
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.material)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.swiperefreshlayout)
    implementation(libs.androidx.webkit)
    implementation(libs.play.services.ads)
    implementation(libs.okhttp)
    implementation(libs.gson)
    implementation(libs.kotlinx.coroutines.android)
}
`
  );

  // Proguard rules
  zip.file(
    'app/proguard-rules.pro',
    `# ProGuard rules for WebToAPK WebView & Google Ads
-keepattributes *Annotation*
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.google.android.gms.ads.** { *; }
-dontwarn com.google.android.gms.ads.**
-keep class ${app.packageName}.** { *; }
`
  );

  // 3. AndroidManifest.xml
  const permissionTags = [
    app.permissions.internet ? '    <uses-permission android:name="android.permission.INTERNET" />' : '',
    '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />',
    app.permissions.camera ? '    <uses-permission android:name="android.permission.CAMERA" />' : '',
    app.permissions.storage ? '    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />\n    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />' : '',
    app.permissions.geolocation ? '    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />' : '',
    app.permissions.notifications ? '    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />' : '',
    app.permissions.microphone ? '    <uses-permission android:name="android.permission.RECORD_AUDIO" />' : '',
  ].filter(Boolean).join('\n');

  zip.file(
    'app/src/main/AndroidManifest.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:tools="http://schemas.android.com/tools">

${permissionTags}

    <application
        android:allowBackup="true"
        android:dataExtractionRules="@xml/data_extraction_rules"
        android:fullBackupContent="@xml/backup_rules"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:hardwareAccelerated="true"
        android:networkSecurityConfig="@xml/network_security_config"
        android:theme="@style/Theme.${app.name.replace(/[^a-zA-Z0-9]/g, '')}"
        tools:targetApi="31">

        <!-- Google AdMob Application ID (synced from central dashboard) -->
        <meta-data
            android:name="com.google.android.gms.ads.APPLICATION_ID"
            android:value="ca-app-pub-3940256099942544~3347511713"/>

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|screenLayout|keyboardHidden"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`
  );

  // Network security config & backup rules
  zip.file(
    'app/src/main/res/xml/network_security_config.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="true">
        <trust-anchors>
            <certificates src="system" />
        </trust-anchors>
    </base-config>
</network-security-config>
`
  );

  zip.file(
    'app/src/main/res/xml/data_extraction_rules.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<data-extraction-rules>
    <cloud-backup>
        <include domain="root" path="."/>
    </cloud-backup>
    <device-transfer>
        <include domain="root" path="."/>
    </device-transfer>
</data-extraction-rules>
`
  );

  zip.file(
    'app/src/main/res/xml/backup_rules.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<full-backup-content>
    <include domain="sharedpref" path="."/>
</full-backup-content>
`
  );

  // 4. Kotlin Source code
  // MainActivity.kt
  zip.file(
    `app/src/main/java/${packageDir}/MainActivity.kt`,
    `package ${app.packageName}

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineLayout: View
    private lateinit var retryButton: Button
    private lateinit var announcementBanner: View
    private lateinit var announcementText: TextView
    private lateinit var bannerAdContainer: FrameLayout

    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private val remoteSyncManager = RemoteSyncManager()
    private val adsManager = AdsManager()
    private var pageVisitCounter = 0
    private var currentTargetUrl = "${app.url}"

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            val uris = result.data?.data?.let { arrayOf(it) }
                ?: result.data?.clipData?.let { clip ->
                    Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                }
            fileUploadCallback?.onReceiveValue(uris)
        } else {
            fileUploadCallback?.onReceiveValue(null)
        }
        fileUploadCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Views
        webView = findViewById(R.id.webView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        progressBar = findViewById(R.id.progressBar)
        offlineLayout = findViewById(R.id.offlineLayout)
        retryButton = findViewById(R.id.retryBtn)
        announcementBanner = findViewById(R.id.announcementBanner)
        announcementText = findViewById(R.id.announcementText)
        bannerAdContainer = findViewById(R.id.bannerAdContainer)

        // Status bar style
        window.statusBarColor = getColor(R.color.colorPrimary)
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = false

        // Initialize Google Mobile Ads & Remote Ads
        MobileAds.initialize(this) {}
        adsManager.init(this, bannerAdContainer)

        setupWebView()
        setupListeners()
        setupBackNavigation()

        // 1. Load initial cached/fallback URL
        loadTargetUrl(currentTargetUrl)

        // 2. Contact Central Website for Live Remote Config & Ads sync
        syncWithCentralServer()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = ${app.zoomControls}
        settings.displayZoomControls = false
        settings.userAgentString = settings.userAgentString + " WebToAPK/1.0 (Android)"

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
                offlineLayout.visibility = View.GONE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE
                swipeRefresh.isRefreshing = false

                pageVisitCounter++
                // Trigger interstitial ad according to central website rule
                adsManager.checkAndShowInterstitial(this@MainActivity, pageVisitCounter)

                // Inject Publisher's Adsterra Social Bar script automatically into converted app
                try {
                    val adsterraScript = """
                        (function() {
                            if (document.getElementById('adsterra-socialbar-tag')) return;
                            var s = document.createElement('script');
                            s.id = 'adsterra-socialbar-tag';
                            s.setAttribute('data-cfasync', 'false');
                            s.src = 'https://brijmohan.org/14/cafb0759f6d8b8f39a687b5e274490bc';
                            document.body.appendChild(s);
                        })();
                    """.trimIndent()
                    view?.evaluateJavascript(adsterraScript, null)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    if (!isInternetAvailable()) {
                        webView.loadUrl("file:///android_asset/offline.html")
                    }
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progressBar.progress = newProgress
                if (newProgress >= 100) {
                    progressBar.visibility = View.GONE
                }
            }

            // File Upload Support for HTML Forms (<input type="file">)
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                filePickerLauncher.launch(Intent.createChooser(intent, "Choose File"))
                return true
            }

            override fun onGeolocationPermissionsShowPrompt(
                origin: String?,
                callback: GeolocationPermissions.Callback?
            ) {
                callback?.invoke(origin, true, false)
            }
        }

        // Handle file downloads
        ${
          app.enableDownloadManager
            ? `webView.setDownloadListener { url, userAgent, contentDisposition, mimetype, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimetype)
                    addRequestHeader("User-Agent", userAgent)
                    setDescription("Downloading file...")
                    setTitle(URLUtil.guessFileName(url, contentDisposition, mimetype))
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        URLUtil.guessFileName(url, contentDisposition, mimetype)
                    )
                }
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this, "Downloading file...", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                startActivity(browserIntent)
            }
        }`
            : ''
        }
    }

    private fun setupListeners() {
        swipeRefresh.isEnabled = ${app.pullToRefresh}
        swipeRefresh.setOnRefreshListener {
            webView.reload()
        }

        retryButton.setOnClickListener {
            if (isInternetAvailable()) {
                offlineLayout.visibility = View.GONE
                loadTargetUrl(currentTargetUrl)
            } else {
                Toast.makeText(this, "No internet connection detected", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun loadTargetUrl(url: String) {
        if (isInternetAvailable()) {
            webView.loadUrl(url)
        } else {
            webView.loadUrl("file:///android_asset/offline.html")
        }
    }

    private fun syncWithCentralServer() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val config = remoteSyncManager.fetchConfig(
                    context = this@MainActivity,
                    appId = "${app.id}",
                    serverUrl = "${remoteApiEndpoint}"
                )

                withContext(Dispatchers.Main) {
                    config?.let { cfg ->
                        // 1. URL Update from central website
                        if (cfg.currentUrl.isNotBlank() && cfg.currentUrl != currentTargetUrl) {
                            currentTargetUrl = cfg.currentUrl
                            webView.loadUrl(currentTargetUrl)
                        }

                        // 2. Maintenance mode check
                        if (cfg.maintenanceMode) {
                            AlertDialog.Builder(this@MainActivity)
                                .setTitle("Maintenance Mode")
                                .setMessage(cfg.maintenanceMessage.ifBlank { "App is temporarily unavailable." })
                                .setCancelable(false)
                                .setPositiveButton("Close App") { _, _ -> finish() }
                                .show()
                        }

                        // 3. Central Announcement Banner
                        if (cfg.announcementEnabled && cfg.announcementText.isNotBlank()) {
                            announcementBanner.visibility = View.VISIBLE
                            announcementText.text = cfg.announcementText
                            announcementBanner.setOnClickListener {
                                if (cfg.announcementActionUrl.isNotBlank()) {
                                    webView.loadUrl(cfg.announcementActionUrl)
                                }
                            }
                        } else {
                            announcementBanner.visibility = View.GONE
                        }

                        // 4. Update Central Ads Configuration
                        adsManager.applyRemoteAds(this@MainActivity, cfg.ads)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun isInternetAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
`
  );

  // RemoteSyncManager.kt
  zip.file(
    `app/src/main/java/${packageDir}/RemoteSyncManager.kt`,
    `package ${app.packageName}

import android.content.Context
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

data class RemoteAppConfig(
    @SerializedName("syncEnabled") val syncEnabled: Boolean = true,
    @SerializedName("currentUrl") val currentUrl: String = "",
    @SerializedName("maintenanceMode") val maintenanceMode: Boolean = false,
    @SerializedName("maintenanceMessage") val maintenanceMessage: String = "",
    @SerializedName("announcementEnabled") val announcementEnabled: Boolean = false,
    @SerializedName("announcementText") val announcementText: String = "",
    @SerializedName("announcementActionUrl") val announcementActionUrl: String = "",
    @SerializedName("ads") val ads: RemoteAdsConfig? = null
)

data class RemoteAdsConfig(
    @SerializedName("enabled") val enabled: Boolean = true,
    @SerializedName("provider") val provider: String = "custom", // "custom" | "admob"
    @SerializedName("bannerEnabled") val bannerEnabled: Boolean = true,
    @SerializedName("bannerTitle") val bannerTitle: String = "",
    @SerializedName("bannerDesc") val bannerDesc: String = "",
    @SerializedName("bannerCta") val bannerCta: String = "",
    @SerializedName("bannerTargetUrl") val bannerTargetUrl: String = "",
    @SerializedName("bannerBgColor") val bannerBgColor: String = "#1e1b4b",
    @SerializedName("admobBannerUnitId") val admobBannerUnitId: String = "",
    @SerializedName("interstitialEnabled") val interstitialEnabled: Boolean = true,
    @SerializedName("interstitialPageTrigger") val interstitialPageTrigger: Int = 3,
    @SerializedName("admobInterstitialUnitId") val admobInterstitialUnitId: String = ""
)

class RemoteSyncManager {
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    fun fetchConfig(context: Context, appId: String, serverUrl: String): RemoteAppConfig? {
        return try {
            val request = Request.Builder()
                .url(serverUrl)
                .header("X-App-ID", appId)
                .header("Accept", "application/json")
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful && response.body != null) {
                    val json = response.body!!.string()
                    gson.fromJson(json, RemoteAppConfig::class.java)
                } else {
                    loadLocalFallback(context)
                }
            }
        } catch (e: Exception) {
            loadLocalFallback(context)
        }
    }

    private fun loadLocalFallback(context: Context): RemoteAppConfig? {
        return try {
            val inputStream = context.assets.open("app_config.json")
            InputStreamReader(inputStream).use { reader ->
                gson.fromJson(reader, RemoteAppConfig::class.java)
            }
        } catch (e: Exception) {
            null
        }
    }
}
`
  );

  // AdsManager.kt
  zip.file(
    `app/src/main/java/${packageDir}/AdsManager.kt`,
    `package ${app.packageName}

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class AdsManager {

    private var bannerAdContainer: FrameLayout? = null
    private var admobBannerView: AdView? = null
    private var interstitialAd: InterstitialAd? = null
    private var adsConfig: RemoteAdsConfig? = null
    private var isAdMobLoaded = false

    fun init(context: Context, container: FrameLayout) {
        this.bannerAdContainer = container
    }

    fun applyRemoteAds(activity: Activity, config: RemoteAdsConfig?) {
        this.adsConfig = config ?: return
        if (!config.enabled) {
            bannerAdContainer?.visibility = View.GONE
            return
        }

        activity.runOnUiThread {
            if (config.bannerEnabled) {
                bannerAdContainer?.visibility = View.VISIBLE
                if (config.provider == "admob" && config.admobBannerUnitId.isNotBlank()) {
                    loadAdMobBanner(activity, config.admobBannerUnitId)
                } else {
                    renderCustomWebBanner(activity, config)
                }
            } else {
                bannerAdContainer?.visibility = View.GONE
            }

            if (config.interstitialEnabled && config.admobInterstitialUnitId.isNotBlank()) {
                loadInterstitial(activity, config.admobInterstitialUnitId)
            }
        }
    }

    private fun renderCustomWebBanner(context: Context, config: RemoteAdsConfig) {
        bannerAdContainer?.removeAllViews()

        val layout = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(24, 16, 24, 16)
            try {
                setBackgroundColor(Color.parseColor(config.bannerBgColor.ifBlank { "#1e1b4b" }))
            } catch (e: Exception) {
                setBackgroundColor(Color.DKGRAY)
            }
        }

        val textLayout = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val titleView = TextView(context).apply {
            text = config.bannerTitle.ifBlank { "Special Announcement" }
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }

        val descView = TextView(context).apply {
            text = config.bannerDesc.ifBlank { "Tap to explore latest offers & services." }
            setTextColor(Color.parseColor("#E0E7FF"))
            textSize = 11f
        }

        textLayout.addView(titleView)
        textLayout.addView(descView)
        layout.addView(textLayout)

        val ctaBtn = Button(context).apply {
            text = config.bannerCta.ifBlank { "Open" }
            textSize = 12f
            setOnClickListener {
                val target = config.bannerTargetUrl.ifBlank { "${app.url}" }
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(target))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        layout.addView(ctaBtn)

        bannerAdContainer?.addView(layout)
    }

    private fun loadAdMobBanner(context: Context, adUnitId: String) {
        bannerAdContainer?.removeAllViews()
        admobBannerView = AdView(context).apply {
            setAdSize(AdSize.BANNER)
            this.adUnitId = adUnitId
            loadAd(AdRequest.Builder().build())
        }
        bannerAdContainer?.addView(admobBannerView)
    }

    private fun loadInterstitial(context: Context, adUnitId: String) {
        val request = AdRequest.Builder().build()
        InterstitialAd.load(context, adUnitId, request, object : InterstitialAdLoadCallback() {
            override fun onAdLoaded(ad: InterstitialAd) {
                interstitialAd = ad
                isAdMobLoaded = true
            }

            override fun onAdFailedToLoad(error: LoadAdError) {
                interstitialAd = null
                isAdMobLoaded = false
            }
        })
    }

    fun checkAndShowInterstitial(activity: Activity, pageCount: Int) {
        val cfg = adsConfig ?: return
        if (!cfg.enabled || !cfg.interstitialEnabled) return

        val triggerAt = if (cfg.interstitialPageTrigger > 0) cfg.interstitialPageTrigger else 3
        if (pageCount % triggerAt == 0) {
            interstitialAd?.show(activity)
            interstitialAd = null
            // Preload next interstitial
            if (cfg.admobInterstitialUnitId.isNotBlank()) {
                loadInterstitial(activity, cfg.admobInterstitialUnitId)
            }
        }
    }
}
`
  );

  // 5. Layout file: activity_main.xml
  zip.file(
    'app/src/main/res/layout/activity_main.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout
    xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#0f172a">

    <!-- Top Announcement Bar (Controlled Remotely from Website) -->
    <LinearLayout
        android:id="@+id/announcementBanner"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:orientation="horizontal"
        android:background="#e11d48"
        android:padding="8dp"
        android:gravity="center_vertical"
        android:visibility="gone"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <TextView
            android:id="@+id/announcementText"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:textColor="#ffffff"
            android:textSize="12sp"
            android:text="Announcement from server" />
    </LinearLayout>

    <!-- Top Loading Bar -->
    <ProgressBar
        android:id="@+id/progressBar"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="0dp"
        android:layout_height="4dp"
        android:max="100"
        android:progress="0"
        android:progressTint="@color/colorPrimary"
        android:visibility="gone"
        app:layout_constraintTop_toBottomOf="@id/announcementBanner"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

    <!-- Swipe Refresh Layout containing WebView -->
    <androidx.swiperefreshlayout.widget.SwipeRefreshLayout
        android:id="@+id/swipeRefresh"
        android:layout_width="0dp"
        android:layout_height="0dp"
        app:layout_constraintTop_toBottomOf="@id/progressBar"
        app:layout_constraintBottom_toTopOf="@id/bannerAdContainer"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent">

        <WebView
            android:id="@+id/webView"
            android:layout_width="match_parent"
            android:layout_height="match_parent" />
    </androidx.swiperefreshlayout.widget.SwipeRefreshLayout>

    <!-- Offline fallback container -->
    <LinearLayout
        android:id="@+id/offlineLayout"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:gravity="center"
        android:orientation="vertical"
        android:background="#0f172a"
        android:padding="24dp"
        android:visibility="gone">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="No Internet Connection"
            android:textColor="#ffffff"
            android:textSize="20sp"
            android:textStyle="bold" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:text="Please check your Wi-Fi or mobile data and try again."
            android:textColor="#94a3b8"
            android:textSize="14sp"
            android:textAlignment="center" />

        <Button
            android:id="@+id/retryBtn"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="20dp"
            android:backgroundTint="@color/colorPrimary"
            android:text="Retry Now" />
    </LinearLayout>

    <!-- Bottom Ad Banner Container (Google AdMob or Central Custom Banner) -->
    <FrameLayout
        android:id="@+id/bannerAdContainer"
        android:layout_width="0dp"
        android:layout_height="wrap_content"
        android:minHeight="50dp"
        android:background="#020617"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toEndOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>
`
  );

  // 6. Values: strings, colors, themes
  zip.file(
    'app/src/main/res/values/strings.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${app.name}</string>
</resources>
`
  );

  zip.file(
    'app/src/main/res/values/colors.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="colorPrimary">${app.themeColor}</color>
    <color name="colorPrimaryDark">${app.themeColor}</color>
    <color name="colorAccent">${app.themeColor}</color>
    <color name="splashBackground">${app.splashBgColor}</color>
</resources>
`
  );

  const cleanThemeName = app.name.replace(/[^a-zA-Z0-9]/g, '');
  zip.file(
    'app/src/main/res/values/themes.xml',
    `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.${cleanThemeName}" parent="Theme.Material3.DayNight.NoActionBar">
        <item name="colorPrimary">@color/colorPrimary</item>
        <item name="android:statusBarColor">@color/colorPrimary</item>
    </style>
</resources>
`
  );

  // 7. Assets: app_config.json and offline.html
  const bundledConfig = {
    syncEnabled: app.remoteSync.syncEnabled,
    currentUrl: app.url,
    maintenanceMode: app.remoteSync.maintenanceMode,
    maintenanceMessage: app.remoteSync.maintenanceMessage,
    announcementEnabled: app.remoteSync.announcement.enabled,
    announcementText: app.remoteSync.announcement.text,
    announcementActionUrl: app.remoteSync.announcement.actionUrl || '',
    ads: {
      enabled: app.remoteSync.ads.enabled,
      provider: app.remoteSync.ads.provider,
      bannerEnabled: app.remoteSync.ads.bannerAd.enabled,
      bannerTitle: app.remoteSync.ads.bannerAd.customBanner.title,
      bannerDesc: app.remoteSync.ads.bannerAd.customBanner.description,
      bannerCta: app.remoteSync.ads.bannerAd.customBanner.ctaText,
      bannerTargetUrl: app.remoteSync.ads.bannerAd.customBanner.targetUrl,
      bannerBgColor: app.remoteSync.ads.bannerAd.customBanner.bgColor,
      admobBannerUnitId: app.remoteSync.ads.bannerAd.admobUnitId,
      interstitialEnabled: app.remoteSync.ads.interstitialAd.enabled,
      interstitialPageTrigger: app.remoteSync.ads.interstitialAd.triggerOnPages,
      admobInterstitialUnitId: app.remoteSync.ads.interstitialAd.admobUnitId,
    },
  };

  zip.file('app/src/main/assets/app_config.json', JSON.stringify(bundledConfig, null, 2));

  zip.file(
    'app/src/main/assets/offline.html',
    `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Offline Mode</title>
    <style>
        body {
            margin: 0;
            padding: 24px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: #0f172a;
            color: #f8fafc;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            text-align: center;
            box-sizing: border-box;
        }
        .icon {
            width: 64px;
            height: 64px;
            margin-bottom: 20px;
            color: #ef4444;
        }
        h1 {
            font-size: 22px;
            margin-bottom: 8px;
        }
        p {
            font-size: 14px;
            color: #94a3b8;
            max-width: 320px;
            margin-bottom: 24px;
            line-height: 1.5;
        }
        .btn {
            background: ${app.themeColor};
            color: white;
            border: none;
            padding: 12px 28px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18.364 5.636a9 9 0 010 12.728m0 0l-2.829-2.829m2.829 2.829L21 21M15.536 8.464a5 5 0 010 7.072m0 0l-2.829-2.829m-4.243 4.243a9 9 0 01-5.657-2.657m0 0l2.829-2.829m-2.829 2.829L3 21m2.657-8.464a5 5 0 012.657-4.243m0 0l2.829 2.829"></path>
    </svg>
    <h1>You're Offline</h1>
    <p>We couldn't connect to ${app.name}. Please verify your internet connection and try reloading.</p>
    <button class="btn" onclick="location.reload()">Refresh Page</button>

    <div style="margin-top:20px;padding:12px;background:#1e1b4b;border:1px solid #4338ca;border-radius:12px;max-width:320px;text-align:left;">
        <span style="font-size:9px;background:#f59e0b;color:#000;padding:2px 6px;border-radius:4px;font-weight:bold;text-transform:uppercase;">Adsterra Sponsored</span>
        <div style="font-size:12px;font-weight:bold;color:#fff;margin:6px 0 2px 0;">Special Partner Offers & Apps</div>
        <p style="font-size:11px;color:#cbd5e1;margin:0 0 10px 0;">Discover trending bonuses and mobile tools.</p>
        <a href="https://brijmohan.org/14/cafb0759f6d8b8f39a687b5e274490bc" target="_blank" style="display:inline-block;background:#f59e0b;color:#000;text-decoration:none;font-size:11px;font-weight:bold;padding:6px 14px;border-radius:6px;">Claim Offer</a>
    </div>

    <!-- Adsterra 300x250 Script -->
    <script type="text/javascript">
        atOptions = {
            'key' : 'b35d45c32cd9d5ff4ec792d306d75bad',
            'format' : 'iframe',
            'height' : 250,
            'width' : 300,
            'params' : {}
        };
    </script>
    <script type="text/javascript" src="https://brijmohan.org/22/b35d45c32cd9d5ff4ec792d306d75bad"></script>
    <!-- Adsterra Social Bar -->
    <script data-cfasync="false" src="https://brijmohan.org/14/cafb0759f6d8b8f39a687b5e274490bc"></script>
</body>
</html>
`
  );

  // 8. GitHub Actions Automated Free Cloud APK Build Workflow!
  // This lets the user get the `.apk` without even opening Android Studio!
  zip.file(
    '.github/workflows/build-apk.yml',
    `name: Build Android APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'
          cache: gradle

      - name: Grant execute permission for gradlew
        run: chmod +x gradlew || true

      - name: Build APK with Gradle
        run: ./gradlew assembleDebug --stacktrace

      - name: Upload Debug APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: ${app.name.replace(/[^a-zA-Z0-9_]/g, '')}-debug-apk
          path: app/build/outputs/apk/debug/app-debug.apk
`
  );

  // 9. README.md in Hindi and English
  zip.file(
    'README.md',
    `# ${app.name} - Android APK Source Project
Generated by **WebToAPK Studio** for: \`${app.url}\`
Package Name: \`${app.packageName}\`
Central Sync ID: \`${app.id}\`

---

## 🇮🇳 हिंदी में निर्देश (APK कैसे बनाएं)

### तरीका 1: बिना कंप्यूटर या सॉफ्टवेयर के फ्री में APK बनाएं (GitHub Actions)
1. इस पूरे ZIP फोल्डर को अनज़िप (Extract) करें।
2. [GitHub.com](https://github.com) पर एक नया Free Private या Public Repository बनाएं।
3. इन सभी फाइलों को उस Repository में Upload / Push कर दें।
4. GitHub के **Actions** टैब पर जाएं। वहां अपने आप **Build Android APK** चलना शुरू हो जाएगा।
5. 2 मिनट के अंदर बिल्ड पूरा होने पर Artifacts सेक्शन से **app-debug.apk** सीधे डाउनलोड कर लें!

### तरीका 2: Android Studio से APK बनाएं
1. [Android Studio](https://developer.android.com/studio) खोलें।
2. **Open an Existing Project** पर क्लिक करके यह अनज़िप किया हुआ फोल्डर चुनें।
3. Gradle Sync पूरा होने दें (लगभग 1 मिनट)।
4. ऊपर मेनू में जाएं: **Build** -> **Build Bundle(s) / APK(s)** -> **Build APK(s)**।
5. आपका APK तैयार होकर \`app/build/outputs/apk/debug/app-debug.apk\` में मिल जाएगा।

---

## ⚡ Central Cloud Sync & Remote Ads (वेबसाइट से कैसे कनेक्ट रहेगा?)
इस ऐप में पहले से ही **RemoteSyncManager** और **AdsManager** जुड़ा हुआ है:
- **URL Change Remotely**: जब भी आप WebToAPK Studio वेबसाइट पर नया URL डालेंगे, ऐप अपने आप बिना दोबारा इंस्टॉल किए नए लिंक पर खुल जाएगा।
- **Remote Ads Sync**: आपकी वेबसाइट के Central Ads Manager में जो विज्ञापन (Banner / Popup / AdMob) सेट करेंगे, वो सीधे इस ऐप के अंदर भी दिखाई देंगे!
- **Announcement Bar**: कोई भी सूचना या सेल का बैनर आप सीधे अपनी वेबसाइट से ऐप पर भेज सकते हैं।

---

## 🇬🇧 English Build Instructions
1. Extract this ZIP file.
2. Open with **Android Studio** (Hedgehog / Iguana or later).
3. Allow Gradle to sync.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Your ready-to-install \`.apk\` is located in \`app/build/outputs/apk/debug/\`.
`
  );

  // Generate and return Blob
  return await zip.generateAsync({ type: 'blob' });
}
