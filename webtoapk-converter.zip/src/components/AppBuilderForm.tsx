import React, { useState } from 'react';
import {
  Globe,
  Smartphone,
  Palette,
  ShieldCheck,
  Download,
  Play,
  RotateCw,
  Sparkles,
  ArrowRight,
  Check,
  Radio,
  FileCode,
} from 'lucide-react';
import { AppConfig } from '../types/app';
import { defaultGlobalAds } from '../services/storage';

interface AppBuilderFormProps {
  currentApp: AppConfig;
  onUpdateApp: (updated: AppConfig) => void;
  onSaveAndPreview: (app: AppConfig) => void;
  onDownloadDirectApk: (app: AppConfig) => void;
  onGenerateZip: (app: AppConfig) => void;
  isGeneratingApk: boolean;
  isGeneratingZip: boolean;
}

const colorPresets = [
  { name: 'Indigo', hex: '#4f46e5' },
  { name: 'Emerald', hex: '#059669' },
  { name: 'Rose', hex: '#e11d48' },
  { name: 'Amber', hex: '#d97706' },
  { name: 'Violet', hex: '#7c3aed' },
  { name: 'Sky', hex: '#0284c7' },
  { name: 'Dark Slate', hex: '#0f172a' },
];

const presets = [
  {
    name: 'E-Commerce Store',
    description: 'Shopping apps with file upload, camera for QR, and pull-to-refresh',
    url: 'https://wikipedia.org',
    appName: 'My Online Store',
    packageName: 'com.store.myonline',
    themeColor: '#4f46e5',
    pullToRefresh: true,
    fileUploads: true,
  },
  {
    name: 'News & Media Blog',
    description: 'High readability, zoom controls, and instant offline caching',
    url: 'https://bbc.com',
    appName: 'Daily News India',
    packageName: 'com.news.dailynews',
    themeColor: '#e11d48',
    pullToRefresh: true,
    fileUploads: false,
  },
  {
    name: 'Business Portfolio',
    description: 'Corporate showcase, fast loading, splash screen branding',
    url: 'https://news.ycombinator.com',
    appName: 'Corporate Hub',
    packageName: 'com.company.hub',
    themeColor: '#059669',
    pullToRefresh: false,
    fileUploads: false,
  },
];

export const AppBuilderForm: React.FC<AppBuilderFormProps> = ({
  currentApp,
  onUpdateApp,
  onSaveAndPreview,
  onDownloadDirectApk,
  onGenerateZip,
  isGeneratingApk,
  isGeneratingZip,
}) => {
  const [formData, setFormData] = useState<AppConfig>({ ...currentApp });
  const [activeTab, setActiveTab] = useState<'basic' | 'theme' | 'permissions' | 'sync'>('basic');
  const [urlInput, setUrlInput] = useState(currentApp.url);

  const handleUrlChange = (value: string) => {
    setUrlInput(value);
    let cleaned = value.trim();
    if (cleaned && !cleaned.startsWith('http://') && !cleaned.startsWith('https://')) {
      cleaned = 'https://' + cleaned;
    }

    // Auto-generate suggested app name and package name if default
    let suggestedName = formData.name;
    let suggestedPackage = formData.packageName;

    try {
      if (cleaned.startsWith('http')) {
        const domain = new URL(cleaned).hostname.replace('www.', '');
        const mainPart = domain.split('.')[0];
        if (mainPart && (!formData.name || formData.name === 'My Android App')) {
          suggestedName = mainPart.charAt(0).toUpperCase() + mainPart.slice(1);
          suggestedPackage = `com.studyhai.${mainPart.toLowerCase()}`;
        }
      }
    } catch {}

    const updated = {
      ...formData,
      url: cleaned,
      name: suggestedName,
      packageName: suggestedPackage,
      remoteSync: {
        ...formData.remoteSync,
        currentUrl: cleaned,
      },
    };
    setFormData(updated);
    onUpdateApp(updated);
  };

  const handleChange = <K extends keyof AppConfig>(key: K, value: AppConfig[K]) => {
    const updated = { ...formData, [key]: value };
    setFormData(updated);
    onUpdateApp(updated);
  };

  const applyPreset = (preset: typeof presets[0]) => {
    const updated: AppConfig = {
      ...formData,
      url: preset.url,
      name: preset.appName,
      packageName: preset.packageName,
      themeColor: preset.themeColor,
      pullToRefresh: preset.pullToRefresh,
      enableFileUploads: preset.fileUploads,
      remoteSync: {
        ...formData.remoteSync,
        currentUrl: preset.url,
      },
    };
    setUrlInput(preset.url);
    setFormData(updated);
    onUpdateApp(updated);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
      {/* Kicker & Title */}
      <div className="mb-6">
        <div className="flex items-center gap-2 text-xs text-indigo-400 font-medium mb-1">
          <span>URL TO ANDROID BUILDER</span>
          <span aria-hidden="true">·</span>
          <span>REAL KOTLIN & GRADLE ENGINE</span>
        </div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          Kisi bhi Website URL ko Android APK me Convert Karein
        </h2>
        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
          Bas website ka URL daalo, app ka naam chuno, aur turant complete Android Source ZIP download karein.
          Aapki website ke central dashboard se ye APK hamesha connect rahega aur ads bhi sync honge!
        </p>
      </div>

      {/* Quick Template Presets */}
      <div className="mb-6">
        <label className="block text-xs font-semibold text-slate-300 mb-2">
          Ready-Made Presets (Quick Setup)
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {presets.map((preset) => (
            <button
              key={preset.name}
              type="button"
              onClick={() => applyPreset(preset)}
              className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 hover:border-indigo-500/50 hover:bg-slate-800/50 text-left transition-all cursor-pointer group"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold text-white group-hover:text-indigo-400">
                  {preset.name}
                </span>
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: preset.themeColor }}
                />
              </div>
              <p className="text-[11px] text-slate-400 line-clamp-1 leading-tight">
                {preset.description}
              </p>
            </button>
          ))}
        </div>
      </div>

      {/* Primary Input: Target URL */}
      <div className="mb-6 p-4 rounded-xl bg-slate-950/80 border border-slate-800 focus-within:border-indigo-500/80 transition-colors">
        <label className="block text-xs font-semibold text-white mb-1.5 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-indigo-400" />
            <span>Website URL (Website ka link yahan daalein)</span>
          </span>
          <span className="text-[10px] text-slate-400 font-normal">HTTP / HTTPS supported</span>
        </label>
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={urlInput}
            onChange={(e) => handleUrlChange(e.target.value)}
            placeholder="https://yourwebsite.com"
            className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 font-mono"
          />
          <button
            type="button"
            onClick={() => onSaveAndPreview(formData)}
            className="px-3.5 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
          >
            <Play className="w-3.5 h-3.5" />
            <span>Load in Simulator</span>
          </button>
        </div>
      </div>

      {/* Tabs for Configuration */}
      <div className="flex items-center gap-1 p-1 bg-slate-950/80 rounded-xl mb-6 border border-slate-800">
        <button
          type="button"
          onClick={() => setActiveTab('basic')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
            activeTab === 'basic' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          App Identity
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('theme')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
            activeTab === 'theme' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          Theme & Colors
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('permissions')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
            activeTab === 'permissions' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          Engine & Features
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('sync')}
          className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1 ${
            activeTab === 'sync' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Radio className="w-3 h-3 text-emerald-400" />
          <span>Cloud Sync & Ads</span>
        </button>
      </div>

      {/* Tab 1: App Identity */}
      {activeTab === 'basic' && (
        <div className="space-y-4 animate-fade-in">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                App Name (Display Name)
              </label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="e.g. Smart Mart"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden focus:border-indigo-500"
              />
              <p className="text-[10px] text-slate-500 mt-1">Shows below icon on Android home screen.</p>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Package Name (Application ID)
              </label>
              <input
                type="text"
                value={formData.packageName}
                onChange={(e) => handleChange('packageName', e.target.value)}
                placeholder="e.g. com.company.appname"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-indigo-500"
              />
              <p className="text-[10px] text-slate-500 mt-1">Unique identifier for Google Play Store.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Version Name
              </label>
              <input
                type="text"
                value={formData.versionName}
                onChange={(e) => handleChange('versionName', e.target.value)}
                placeholder="1.0.0"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Version Code
              </label>
              <input
                type="number"
                value={formData.versionCode}
                onChange={(e) => handleChange('versionCode', parseInt(e.target.value) || 1)}
                min="1"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono focus:outline-hidden focus:border-indigo-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Theme & Colors */}
      {activeTab === 'theme' && (
        <div className="space-y-4 animate-fade-in">
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-2">
              Status Bar & Primary Brand Color
            </label>
            <div className="flex items-center gap-3 mb-3">
              <input
                type="color"
                value={formData.themeColor}
                onChange={(e) => handleChange('themeColor', e.target.value)}
                className="w-10 h-10 rounded-lg cursor-pointer bg-transparent border-0"
              />
              <input
                type="text"
                value={formData.themeColor}
                onChange={(e) => handleChange('themeColor', e.target.value)}
                className="w-32 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {colorPresets.map((color) => (
                <button
                  key={color.name}
                  type="button"
                  onClick={() => handleChange('themeColor', color.hex)}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-medium flex items-center gap-1.5 border transition-colors ${
                    formData.themeColor.toLowerCase() === color.hex.toLowerCase()
                      ? 'border-white text-white bg-slate-800'
                      : 'border-slate-800 text-slate-400 hover:text-white bg-slate-950'
                  }`}
                >
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color.hex }} />
                  <span>{color.name}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-800">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Splash Screen Background
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={formData.splashBgColor}
                  onChange={(e) => handleChange('splashBgColor', e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer bg-transparent border-0"
                />
                <input
                  type="text"
                  value={formData.splashBgColor}
                  onChange={(e) => handleChange('splashBgColor', e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Splash Duration (ms)
              </label>
              <select
                value={formData.splashDurationMs}
                onChange={(e) => handleChange('splashDurationMs', parseInt(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-hidden"
              >
                <option value={1000}>1.0 second (Fast)</option>
                <option value={1500}>1.5 seconds (Standard)</option>
                <option value={2000}>2.0 seconds</option>
                <option value={3000}>3.0 seconds (Branded)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Engine & Permissions */}
      {activeTab === 'permissions' && (
        <div className="space-y-4 animate-fade-in">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.pullToRefresh}
                onChange={(e) => handleChange('pullToRefresh', e.target.checked)}
                className="mt-0.5 rounded text-indigo-600 focus:ring-0"
              />
              <div>
                <p className="text-xs font-semibold text-white">Pull-to-Refresh</p>
                <p className="text-[11px] text-slate-400">
                  Allows user to swipe down from the top to reload the page.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableFileUploads}
                onChange={(e) => handleChange('enableFileUploads', e.target.checked)}
                className="mt-0.5 rounded text-indigo-600 focus:ring-0"
              />
              <div>
                <p className="text-xs font-semibold text-white">Camera & File Uploads</p>
                <p className="text-[11px] text-slate-400">
                  Enables HTML file inputs, photo picking, and document uploads.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.enableDownloadManager}
                onChange={(e) => handleChange('enableDownloadManager', e.target.checked)}
                className="mt-0.5 rounded text-indigo-600 focus:ring-0"
              />
              <div>
                <p className="text-xs font-semibold text-white">Android Download Manager</p>
                <p className="text-[11px] text-slate-400">
                  Directly saves PDF, ZIP, and images to phone storage.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.offlineSupport}
                onChange={(e) => handleChange('offlineSupport', e.target.checked)}
                className="mt-0.5 rounded text-indigo-600 focus:ring-0"
              />
              <div>
                <p className="text-xs font-semibold text-white">Offline Fallback Screen</p>
                <p className="text-[11px] text-slate-400">
                  Shows clean embedded offline screen with Retry button when offline.
                </p>
              </div>
            </label>
          </div>

          <div className="pt-2 border-t border-slate-800">
            <p className="text-xs font-semibold text-slate-300 mb-2">Android Manifest Permissions</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              {(['internet', 'camera', 'storage', 'geolocation'] as const).map((perm) => (
                <label key={perm} className="flex items-center gap-2 p-2 rounded bg-slate-950 border border-slate-800">
                  <input
                    type="checkbox"
                    checked={formData.permissions[perm]}
                    onChange={(e) => {
                      const updatedPerms = { ...formData.permissions, [perm]: e.target.checked };
                      handleChange('permissions', updatedPerms);
                    }}
                    className="rounded text-indigo-600"
                  />
                  <span className="capitalize text-slate-300">{perm}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Cloud Sync & Ads */}
      {activeTab === 'sync' && (
        <div className="space-y-4 animate-fade-in">
          <div className="p-4 rounded-xl bg-indigo-950/30 border border-indigo-500/30">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span className="text-xs font-bold text-white">
                    Central Website Sync Engine (Connected)
                  </span>
                </div>
                <p className="text-xs text-indigo-200/80 leading-relaxed">
                  Is APK me ek live background sync coroutine judaa hua hai. Jab bhi aap website se URL badlenge
                  ya naye ads chalayenge, sabhi users ke phone me turant update ho jayega!
                </p>
              </div>
              <div className="shrink-0 text-right">
                <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-2 py-0.5 rounded">
                  ACTIVE
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800">
              <input
                type="checkbox"
                checked={formData.remoteSync.syncEnabled}
                onChange={(e) => {
                  const updatedSync = { ...formData.remoteSync, syncEnabled: e.target.checked };
                  handleChange('remoteSync', updatedSync);
                }}
                className="mt-0.5 rounded text-indigo-600"
              />
              <div>
                <p className="text-xs font-semibold text-white">Enable Remote URL Updates</p>
                <p className="text-[11px] text-slate-400">
                  Allows changing the app's website address without rebuilding or redistributing the APK.
                </p>
              </div>
            </label>

            <label className="flex items-start gap-3 p-3 rounded-xl bg-slate-950 border border-slate-800">
              <input
                type="checkbox"
                checked={formData.remoteSync.ads.enabled}
                onChange={(e) => {
                  const updatedAds = { ...formData.remoteSync.ads, enabled: e.target.checked };
                  const updatedSync = { ...formData.remoteSync, ads: updatedAds };
                  handleChange('remoteSync', updatedSync);
                }}
                className="mt-0.5 rounded text-indigo-600"
              />
              <div>
                <p className="text-xs font-semibold text-white">
                  Monetization & Ads Sync (Jo website pe ads chalenge, app pe bhi chalenge)
                </p>
                <p className="text-[11px] text-slate-400">
                  Connects this app to your Central Ads Manager to display bottom banner and interstitial ads.
                </p>
              </div>
            </label>
          </div>
        </div>
      )}

      {/* Parse Error Prevention Info Banner */}
      <div className="mt-8 p-3.5 rounded-xl bg-amber-950/30 border border-amber-500/40 flex items-start gap-3">
        <Sparkles className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-amber-200/90 leading-relaxed">
          <span className="font-bold text-white">Android Phone Compatibility Note:</span> Agar direct .APK file phone me install karte waqt <span className="font-semibold text-amber-300">"There was a problem parsing the package"</span> dikhaye, toh <strong className="text-emerald-300">"Source Code (ZIP)"</strong> download karein. Usme included GitHub Actions se 1 minute me official Google SDK signed APK mil jayega jo 100% kisi bhi phone me install hota hai!
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-4 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => onSaveAndPreview(formData)}
          className="px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer"
        >
          <Play className="w-3.5 h-3.5 text-indigo-400" />
          <span>Save & Update Simulator</span>
        </button>

        <div className="flex flex-col sm:flex-row items-center gap-2.5">
          <button
            type="button"
            onClick={() => onGenerateZip(formData)}
            disabled={isGeneratingZip}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-colors shadow-md shadow-indigo-600/25 flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50"
            title="Download full project folder with GitHub Actions 1-min APK compiler"
          >
            <FileCode className="w-3.5 h-3.5 text-white" />
            <span>{isGeneratingZip ? 'Preparing ZIP...' : 'Download Project (ZIP) - 100% Real APK'}</span>
          </button>

          <button
            type="button"
            onClick={() => onDownloadDirectApk(formData)}
            disabled={isGeneratingApk}
            className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4" />
            <span>{isGeneratingApk ? 'Compiling APK...' : 'Instant APK (.apk)'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
