import React, { useState } from 'react';
import {
  BookOpen,
  Check,
  Copy,
  Terminal,
  ExternalLink,
  Smartphone,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  FileCode,
} from 'lucide-react';

export const BuildGuideModal: React.FC = () => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-2 text-xs text-indigo-400 font-medium mb-1">
          <BookOpen className="w-3.5 h-3.5" />
          <span>STEP-BY-STEP APK COMPILATION GUIDE</span>
          <span aria-hidden="true">·</span>
          <span>HINDI & ENGLISH</span>
        </div>
        <h2 className="text-xl font-bold text-white tracking-tight">
          Android APK (.apk) Build Aur Install Karne Ka Sahi Tareeqa
        </h2>
        <p className="text-xs text-slate-400 mt-1 max-w-2xl">
          Niche 2 aasan tareeqe diye gaye hain jisse aapka APK har ek Android phone me 100% bina kisi error ke install ho sake:
        </p>
      </div>

      {/* Parse Error Solution Box */}
      <div className="bg-amber-950/30 border border-amber-500/40 rounded-2xl p-5 shadow-lg">
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm shrink-0 border border-amber-500/30">
            !
          </div>
          <div>
            <h4 className="text-sm font-bold text-white mb-1">
              "There was a problem parsing the package" Error Kyun Aata Hai?
            </h4>
            <p className="text-xs text-amber-200/90 leading-relaxed">
              Android phone ka internal security system kisi bhi application ko install karne se pehle official Google Android SDK ka certified signature aur compiled Dalvik bytecode mangta hai. Agar browser se direct download kiya package aapke phone ke architecture se match na kare, toh phone <strong>"Problem parsing the package"</strong> dikha deta hai.
            </p>
            <p className="text-xs text-emerald-400 font-semibold mt-2">
              ✅ Iska 100% Solution: Niche diya gaya "Tareeqa 1 (GitHub Cloud Compiler)" use karein. Wahan Google ke official Android build server par 1 minute me aapka APK free me compile ho jata hai jo sabhi phone me smoothly install hota hai!
            </p>
          </div>
        </div>
      </div>

      {/* Method 1: Free GitHub Actions (No PC required!) */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs border border-emerald-500/30">
              1
            </span>
            <h3 className="text-sm font-bold text-white">
              Tareeqa 1: Bina Computer ya Heavy Software ke Free me APK Banayein (GitHub Actions)
            </h3>
          </div>
          <span className="text-[10px] font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded">
            RECOMMENDED (Sabse Aasan)
          </span>
        </div>

        <p className="text-xs text-slate-300 mb-4 leading-relaxed">
          Aapke downloaded ZIP me pehle se hi ek automated GitHub Action workflow (<code className="text-indigo-300 font-mono">.github/workflows/build-apk.yml</code>) shamil hai. Iska faayda ye hai ki cloud par 2 minute me aapka APK apne aap compile hokar download ke liye mil jata hai!
        </p>

        <div className="space-y-3 mb-4">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">Step 1:</span>
            <div className="text-xs text-slate-300">
              Downloaded ZIP file ko apne computer ya phone me extract (unzip) karein.
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">Step 2:</span>
            <div className="text-xs text-slate-300">
              <a
                href="https://github.com"
                target="_blank"
                rel="noreferrer"
                className="text-indigo-400 underline font-semibold"
              >
                GitHub.com
              </a>{' '}
              par ek naya repository banayein (Private ya Public) aur in sabhi unzipped files ko wahan upload kar dein.
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">Step 3:</span>
            <div className="text-xs text-slate-300">
              GitHub repository ke <strong>Actions</strong> tab par jayein. Wahan apne aap <strong>Build Android APK</strong> chalna shuru ho jayega.
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">Step 4:</span>
            <div className="text-xs text-slate-300">
              Green tick aate hi click karein aur <strong>Artifacts</strong> section se ready-to-install <code className="text-emerald-400 font-mono">app-debug.apk</code> download kar lein!
            </div>
          </div>
        </div>
      </div>

      {/* Method 2: Android Studio */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex items-center gap-2 mb-4">
          <span className="w-6 h-6 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs border border-indigo-500/30">
            2
          </span>
          <h3 className="text-sm font-bold text-white">
            Tareeqa 2: Official Android Studio se APK Build Karein (Standard Developer Flow)
          </h3>
        </div>

        <div className="space-y-3 mb-4">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">Step 1:</span>
            <div className="text-xs text-slate-300">
              Android Studio kholein aur <strong>Open</strong> par click karke extracted folder ko select karein.
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">Step 2:</span>
            <div className="text-xs text-slate-300">
              Gradle sync complete hone ka wait karein (pehli baar 1-2 minute lag sakta hai).
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">Step 3:</span>
            <div className="text-xs text-slate-300">
              Top menu me jayein: <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start gap-3">
            <span className="text-xs font-bold text-indigo-400 font-mono">Terminal:</span>
            <div className="w-full">
              <p className="text-xs text-slate-300 mb-2">Ya direct terminal command se build karein:</p>
              <div className="p-2.5 rounded-lg bg-black text-emerald-400 font-mono text-xs flex items-center justify-between">
                <code>./gradlew assembleDebug</code>
                <button
                  onClick={() => copyToClipboard('./gradlew assembleDebug', 'cmd')}
                  className="text-slate-400 hover:text-white"
                >
                  {copiedKey === 'cmd' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
