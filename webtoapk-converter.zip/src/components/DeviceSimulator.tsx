import React, { useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  Battery,
  RotateCw,
  ArrowLeft,
  X,
  ExternalLink,
  Download,
  AlertCircle,
  Megaphone,
  Radio,
  Sparkles,
  FileCode,
} from 'lucide-react';
import { AppConfig } from '../types/app';
import { generateAndroidProjectZip } from '../services/zipGenerator';

interface DeviceSimulatorProps {
  app: AppConfig;
  onDownloadDirectApk: () => void;
  onDownloadZip: () => void;
  isDownloadingApk?: boolean;
  isDownloadingZip?: boolean;
}

export const DeviceSimulator: React.FC<DeviceSimulatorProps> = ({
  app,
  onDownloadDirectApk,
  onDownloadZip,
  isDownloadingApk = false,
  isDownloadingZip = false,
}) => {
  const [currentTime, setCurrentTime] = useState('12:45');
  const [isSimulatedOffline, setIsSimulatedOffline] = useState(false);
  const [showInterstitial, setShowInterstitial] = useState(false);
  const [interstitialCountdown, setInterstitialCountdown] = useState(5);
  const [iframeError, setIframeError] = useState(false);
  const [isLoadingPage, setIsLoadingPage] = useState(false);
  const [key, setKey] = useState(0);

  // Status bar time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  // Interstitial countdown
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (showInterstitial && interstitialCountdown > 0) {
      timer = setTimeout(() => {
        setInterstitialCountdown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearTimeout(timer);
  }, [showInterstitial, interstitialCountdown]);

  const handleRefresh = () => {
    setIsLoadingPage(true);
    setKey((prev) => prev + 1);
    setTimeout(() => setIsLoadingPage(false), 800);
  };

  const handleTriggerInterstitial = () => {
    setInterstitialCountdown(4);
    setShowInterstitial(true);
  };

  const bannerAd = app.remoteSync.ads.bannerAd;
  const isAdsEnabled = app.remoteSync.ads.enabled && bannerAd.enabled;

  return (
    <div className="flex flex-col items-center">
      {/* Device Toolbar */}
      <div className="w-full max-w-[380px] mb-3 flex items-center justify-between px-2 text-xs text-slate-400">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-500" />
          <span className="font-medium text-slate-300">Live Android Preview</span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIsSimulatedOffline(!isSimulatedOffline)}
            title="Toggle simulated network connectivity"
            className={`p-1.5 rounded transition-colors ${
              isSimulatedOffline
                ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                : 'hover:bg-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            {isSimulatedOffline ? <WifiOff className="w-4 h-4" /> : <Wifi className="w-4 h-4" />}
          </button>
          <button
            onClick={handleTriggerInterstitial}
            title="Simulate Interstitial Popup Ad"
            className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors flex items-center gap-1"
          >
            <Megaphone className="w-3.5 h-3.5 text-amber-400" />
            <span>Test Ad</span>
          </button>
          <button
            onClick={handleRefresh}
            title="Reload Webview"
            className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-slate-200 transition-colors"
          >
            <RotateCw className={`w-4 h-4 ${isLoadingPage ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Phone Casing */}
      <div className="relative w-[340px] h-[670px] bg-slate-900 rounded-[44px] p-3 shadow-2xl ring-1 ring-slate-700/60 shadow-indigo-950/40 flex flex-col">
        {/* Outer Phone Border Accent */}
        <div className="absolute inset-0 rounded-[44px] pointer-events-none border border-slate-700/50" />

        {/* Screen Frame */}
        <div className="relative w-full h-full bg-slate-950 rounded-[34px] overflow-hidden flex flex-col border border-slate-800/80">
          
          {/* Status Bar */}
          <div
            style={{ backgroundColor: app.themeColor }}
            className="h-7 px-5 flex items-center justify-between text-white text-[11px] font-semibold select-none z-30 transition-colors"
          >
            <span>{currentTime}</span>
            {/* Punch hole camera */}
            <div className="w-3 h-3 rounded-full bg-black/80 ring-1 ring-white/10" />
            <div className="flex items-center gap-1.5 text-white/90">
              <span className="text-[9px] font-mono">5G</span>
              {isSimulatedOffline ? <WifiOff className="w-3 h-3 text-red-300" /> : <Wifi className="w-3 h-3" />}
              <Battery className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* App Bar (Header in App) */}
          <div
            style={{ backgroundColor: app.themeColor }}
            className="h-11 px-3 flex items-center justify-between text-white border-t border-white/10 shadow-sm z-20 transition-colors"
          >
            <div className="flex items-center gap-2 overflow-hidden">
              <div className="w-6 h-6 rounded-md bg-white/20 flex items-center justify-center font-bold text-xs uppercase shrink-0">
                {app.name.charAt(0) || 'A'}
              </div>
              <span className="text-xs font-semibold truncate tracking-tight">
                {app.name || 'My Android App'}
              </span>
            </div>
            <div className="flex items-center gap-1 text-white/80">
              <button
                onClick={handleRefresh}
                className="p-1 hover:bg-white/15 rounded transition-colors"
                title="Reload"
              >
                <RotateCw className="w-3.5 h-3.5" />
              </button>
              <a
                href={app.url}
                target="_blank"
                rel="noreferrer"
                className="p-1 hover:bg-white/15 rounded transition-colors"
                title="Open original website"
              >
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>

          {/* Announcement Bar (synced from central website) */}
          {app.remoteSync.announcement.enabled && app.remoteSync.announcement.text && !isSimulatedOffline && (
            <div className="bg-rose-600 px-3 py-1.5 text-white text-[11px] font-medium flex items-center justify-between gap-2 shadow-sm animate-fade-in z-20">
              <div className="flex items-center gap-1.5 truncate">
                <Radio className="w-3 h-3 animate-pulse shrink-0 text-amber-200" />
                <span className="truncate">{app.remoteSync.announcement.text}</span>
              </div>
              {app.remoteSync.announcement.actionUrl && (
                <span className="text-[10px] underline shrink-0 cursor-pointer">View</span>
              )}
            </div>
          )}

          {/* Maintenance Notice (if remote maintenance is ON) */}
          {app.remoteSync.maintenanceMode && !isSimulatedOffline && (
            <div className="bg-amber-500/20 border-b border-amber-500/40 px-3 py-2 text-amber-200 text-xs flex items-center gap-2 z-20">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="text-[11px] leading-tight">
                <p className="font-bold">Maintenance Mode Active</p>
                <p className="text-amber-300/80">{app.remoteSync.maintenanceMessage || 'Server under maintenance'}</p>
              </div>
            </div>
          )}

          {/* Progress Bar */}
          {isLoadingPage && (
            <div className="h-0.5 w-full bg-slate-800 overflow-hidden z-20">
              <div className="h-full bg-white animate-pulse w-2/3" />
            </div>
          )}

          {/* Top Banner Ad (if position is top) */}
          {isAdsEnabled && bannerAd.position === 'top' && !isSimulatedOffline && (
            <div
              style={{ backgroundColor: bannerAd.customBanner.bgColor || '#1e1b4b' }}
              className="p-2 border-b border-white/10 z-20 flex items-center justify-between gap-2 text-white"
            >
              <div className="truncate">
                <p className="text-[11px] font-bold leading-tight truncate">
                  {bannerAd.customBanner.title}
                </p>
                <p className="text-[9px] text-indigo-200 truncate">
                  {bannerAd.customBanner.description}
                </p>
              </div>
              <a
                href={bannerAd.customBanner.targetUrl || '#'}
                target="_blank"
                rel="noreferrer"
                className="px-2 py-0.5 rounded text-[10px] font-semibold bg-white text-slate-900 whitespace-nowrap"
              >
                {bannerAd.customBanner.ctaText || 'Open'}
              </a>
            </div>
          )}

          {/* Main Content Area (Simulated WebView) */}
          <div className="flex-1 relative bg-slate-950 overflow-hidden flex flex-col">
            {isSimulatedOffline ? (
              // Offline fallback view
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-slate-900 text-slate-100">
                <div className="w-12 h-12 rounded-full bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mb-3">
                  <WifiOff className="w-6 h-6" />
                </div>
                <h4 className="text-sm font-bold text-white mb-1">You are Offline</h4>
                <p className="text-[11px] text-slate-400 mb-4 max-w-[200px] leading-relaxed">
                  Unable to connect to {app.name}. Please verify your internet connection.
                </p>
                <button
                  onClick={() => setIsSimulatedOffline(false)}
                  style={{ backgroundColor: app.themeColor }}
                  className="px-4 py-1.5 text-xs font-semibold text-white rounded-lg shadow-sm cursor-pointer"
                >
                  Retry Connection
                </button>
              </div>
            ) : iframeError ? (
              // Fallback if website blocks iframe embedding
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-slate-900/90 text-slate-200">
                <div className="w-10 h-10 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 mb-2">
                  <ExternalLink className="w-5 h-5" />
                </div>
                <h5 className="text-xs font-bold text-white mb-1">Target URL Connected</h5>
                <p className="text-[11px] text-slate-400 mb-3 truncate max-w-[240px] font-mono">
                  {app.url}
                </p>
                <p className="text-[10px] text-slate-500 max-w-[220px] mb-4">
                  (In real Android APK, the site will load natively without browser iframe restrictions)
                </p>
                <div className="flex flex-col gap-2 w-full max-w-[200px]">
                  <a
                    href={app.url}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-white rounded text-center transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Test in New Tab</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                  <button
                    onClick={() => setIframeError(false)}
                    className="text-[10px] text-indigo-400 underline"
                  >
                    Try embedding again
                  </button>
                </div>
              </div>
            ) : (
              // Live WebView Iframe
              <iframe
                key={key}
                src={app.url}
                title="WebView Simulator"
                className="w-full h-full border-0 bg-white"
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
                onError={() => setIframeError(true)}
              />
            )}

            {/* Interstitial Popup Ad Modal */}
            {showInterstitial && (
              <div className="absolute inset-0 bg-black/80 backdrop-blur-xs z-50 flex flex-col items-center justify-center p-4 animate-fade-in">
                <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-[280px] p-4 text-center shadow-2xl relative">
                  <div className="flex items-center justify-between mb-3 text-slate-400">
                    <span className="text-[10px] uppercase tracking-wider font-semibold bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded">
                      Sponsored Ad
                    </span>
                    {interstitialCountdown > 0 ? (
                      <span className="text-[11px] font-mono text-slate-400">
                        Skip in {interstitialCountdown}s
                      </span>
                    ) : (
                      <button
                        onClick={() => setShowInterstitial(false)}
                        className="p-1 rounded-full bg-slate-800 hover:bg-slate-700 text-white transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="w-full h-28 bg-slate-800 rounded-lg overflow-hidden mb-3 relative flex items-center justify-center">
                    <div className="absolute inset-0 bg-gradient-to-tr from-indigo-900/40 to-amber-900/30" />
                    <Sparkles className="w-8 h-8 text-amber-400 relative z-10" />
                  </div>

                  <h4 className="text-xs font-bold text-white mb-1">
                    {app.remoteSync.ads.interstitialAd.customInterstitial.title || 'Special Promotion'}
                  </h4>
                  <p className="text-[10px] text-slate-400 mb-3 leading-relaxed">
                    {app.remoteSync.ads.interstitialAd.customInterstitial.description ||
                      'Exclusive partner deal configured in your WebToAPK Central Ads Manager.'}
                  </p>

                  <a
                    href={app.remoteSync.ads.interstitialAd.customInterstitial.targetUrl || '#'}
                    target="_blank"
                    rel="noreferrer"
                    className="block w-full py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500 rounded-lg transition-colors text-center"
                  >
                    {app.remoteSync.ads.interstitialAd.customInterstitial.ctaText || 'Learn More'}
                  </a>
                </div>
              </div>
            )}
          </div>

          {/* Bottom Banner Ad (Synced from Central Ads Manager) */}
          {isAdsEnabled && bannerAd.position === 'bottom' && !isSimulatedOffline && (
            <div
              style={{ backgroundColor: bannerAd.customBanner.bgColor || '#1e1b4b' }}
              className="p-2 border-t border-white/10 z-20 flex items-center justify-between gap-2 text-white shadow-lg shrink-0"
            >
              <div className="flex items-center gap-2 truncate">
                <div className="w-7 h-7 rounded bg-amber-400/20 text-amber-300 flex items-center justify-center font-bold text-[10px] shrink-0 border border-amber-400/30">
                  AD
                </div>
                <div className="truncate">
                  <p className="text-[11px] font-bold leading-tight truncate">
                    {bannerAd.customBanner.title}
                  </p>
                  <p className="text-[9px] text-indigo-200 truncate">
                    {bannerAd.customBanner.description}
                  </p>
                </div>
              </div>
              <a
                href={bannerAd.customBanner.targetUrl || '#'}
                target="_blank"
                rel="noreferrer"
                className="px-2.5 py-1 rounded text-[10px] font-semibold bg-white text-slate-900 hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0 shadow-xs"
              >
                {bannerAd.customBanner.ctaText || 'Claim'}
              </a>
            </div>
          )}

          {/* Android System Navigation Bar */}
          <div className="h-6 bg-slate-950 flex items-center justify-around px-12 text-slate-500 select-none z-30">
            <button
              onClick={() => {
                if (iframeError) setIframeError(false);
                else handleRefresh();
              }}
              title="Android Back Button"
              className="hover:text-slate-300 transition-colors"
            >
              <ArrowLeft className="w-3 h-3" />
            </button>
            <button
              onClick={handleRefresh}
              title="Android Home Button"
              className="hover:text-slate-300 transition-colors"
            >
              <div className="w-2.5 h-2.5 rounded-full border border-slate-500" />
            </button>
            <button
              title="Android Recents Button"
              className="hover:text-slate-300 transition-colors"
            >
              <div className="w-2.5 h-2.5 border border-slate-500 rounded-xs" />
            </button>
          </div>
        </div>
      </div>

      {/* Simulator Bottom Actions */}
      <div className="mt-4 flex flex-col items-center gap-2 w-full max-w-[340px]">
        <button
          onClick={onDownloadZip}
          disabled={isDownloadingZip}
          className="w-full py-2.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-colors shadow-md shadow-indigo-600/30 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
        >
          <FileCode className="w-4 h-4 text-white" />
          <span>{isDownloadingZip ? 'Preparing ZIP...' : 'Download Project ZIP (100% Real APK)'}</span>
        </button>

        <button
          onClick={onDownloadDirectApk}
          disabled={isDownloadingApk}
          className="w-full py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition-all border border-slate-700 flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
        >
          <Download className="w-3.5 h-3.5 text-emerald-400" />
          <span>{isDownloadingApk ? 'Compiling .APK File...' : 'Instant .APK File (Experimental)'}</span>
        </button>

        <p className="text-[11px] text-amber-300/90 text-center leading-tight">
          💡 Phone me Parse Error se bachne ke liye <strong>Project ZIP</strong> download karke GitHub Actions se official APK compile karein.
        </p>
      </div>
    </div>
  );
};
