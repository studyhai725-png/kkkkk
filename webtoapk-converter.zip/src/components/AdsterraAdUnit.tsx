import React, { useEffect, useRef } from 'react';

interface AdsterraBannerProps {
  zoneKey?: string;
  scriptUrl?: string;
  width?: number;
  height?: number;
}

export const AdsterraBanner300x250: React.FC<AdsterraBannerProps> = ({
  zoneKey = 'b35d45c32cd9d5ff4ec792d306d75bad',
  scriptUrl = 'https://brijmohan.org/22/b35d45c32cd9d5ff4ec792d306d75bad',
  width = 300,
  height = 250,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;
    const container = containerRef.current;
    container.innerHTML = '';

    // Create an isolated iframe so Adsterra document.write doesn't conflict with React Virtual DOM
    const iframe = document.createElement('iframe');
    iframe.width = `${width}`;
    iframe.height = `${height}`;
    iframe.style.border = 'none';
    iframe.style.overflow = 'hidden';
    iframe.scrolling = 'no';
    container.appendChild(iframe);

    const doc = iframe.contentWindow?.document || iframe.contentDocument;
    if (doc) {
      doc.open();
      doc.write(`
        <!DOCTYPE html>
        <html>
        <head>
          <style>body{margin:0;padding:0;background:transparent;display:flex;align-items:center;justify-content:center;}</style>
        </head>
        <body>
          <script type="text/javascript">
            atOptions = {
              'key': '${zoneKey}',
              'format': 'iframe',
              'height': ${height},
              'width': ${width},
              'params': {}
            };
          </script>
          <script type="text/javascript" src="${scriptUrl}"></script>
        </body>
        </html>
      `);
      doc.close();
    }
  }, [zoneKey, scriptUrl, width, height]);

  return (
    <div className="flex flex-col items-center justify-center my-3">
      <div className="text-[10px] text-slate-500 uppercase tracking-widest font-mono mb-1">
        Sponsored by Adsterra
      </div>
      <div
        ref={containerRef}
        className="w-[300px] h-[250px] bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg flex items-center justify-center"
      />
    </div>
  );
};
