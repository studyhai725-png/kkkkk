import React from 'react';
import { ExternalLink, Megaphone, Sparkles } from 'lucide-react';
import { AdsterraConfig } from '../types/app';

interface WebsiteAdBannerProps {
  adsterra?: AdsterraConfig;
}

export const WebsiteAdBanner: React.FC<WebsiteAdBannerProps> = ({ adsterra }) => {
  if (!adsterra?.enabled) return null;

  const handleClickAd = () => {
    if (adsterra?.directLink) {
      window.open(adsterra.directLink, '_blank', 'noopener,noreferrer');
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 my-4">
      <div
        onClick={handleClickAd}
        className="w-full bg-gradient-to-r from-slate-900 via-indigo-950/70 to-slate-900 border border-indigo-500/30 hover:border-amber-500/50 rounded-2xl p-3 sm:p-4 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-3 cursor-pointer transition-all group"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0 border border-amber-400/30">
            ADS
          </div>
          <div className="text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-2">
              <span className="text-[10px] font-bold uppercase text-amber-400">Adsterra Sponsored</span>
              <span className="text-[10px] text-slate-500">·</span>
              <span className="text-[10px] text-slate-400">Recommended Partner</span>
            </div>
            <p className="text-xs sm:text-sm font-bold text-white group-hover:text-amber-300 transition-colors">
              Boost Your Website Traffic & Monetization with High CPM Solutions
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="px-3 py-1.5 rounded-lg bg-amber-500 group-hover:bg-amber-400 text-slate-950 text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm">
            <span>Explore Deals</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </span>
        </div>
      </div>
    </div>
  );
};
