import React, { useState } from 'react';
import {
  Megaphone,
  Check,
  Radio,
  Sliders,
  DollarSign,
  Smartphone,
  Eye,
  RefreshCw,
  ExternalLink,
  Sparkles,
  ShieldAlert,
} from 'lucide-react';
import { AdConfig, AppConfig } from '../types/app';
import { storage } from '../services/storage';
import { AdsterraBanner300x250 } from './AdsterraAdUnit';

interface CentralAdsManagerProps {
  globalAds: AdConfig;
  onUpdateGlobalAds: (updated: AdConfig) => void;
  apps: AppConfig[];
  onSelectAppForPreview: (app: AppConfig) => void;
}

export const CentralAdsManager: React.FC<CentralAdsManagerProps> = ({
  globalAds,
  onUpdateGlobalAds,
  apps,
  onSelectAppForPreview,
}) => {
  const [ads, setAds] = useState<AdConfig>({ ...globalAds });
  const [syncedNotification, setSyncedNotification] = useState(false);
  const [activeTab, setActiveTab] = useState<'adsterra' | 'banner' | 'interstitial' | 'admob'>('adsterra');

  const handleToggleGlobal = (enabled: boolean) => {
    const updated = { ...ads, enabled };
    setAds(updated);
    onUpdateGlobalAds(updated);
  };

  const handleAdsterraChange = <K extends keyof AdConfig['adsterra']>(
    key: K,
    value: AdConfig['adsterra'][K]
  ) => {
    const currentAdsterra = ads.adsterra || {
      enabled: true,
      directLink: 'https://www.profitablecpmrate.com/d87f91a92e104',
      bannerZoneKey: '9e7a812bf1b402129c991a0c028a4911',
      bannerScriptUrl: '//www.highperformanceformat.com/9e7a812bf1b402129c991a0c028a4911/invoke.js',
      socialBarScript: '//pl22184920.profitablecpmrate.com/89/34/cd/8934cd9912099c99.js',
      popunderUrl: 'https://www.profitablecpmrate.com/d87f91a92e104',
      forceAdBeforeDownload: true,
      countdownSeconds: 5,
    };
    const updated: AdConfig = {
      ...ads,
      adsterra: {
        ...currentAdsterra,
        [key]: value,
      },
    };
    setAds(updated);
    onUpdateGlobalAds(updated);
  };

  const handleBannerChange = <K extends keyof AdConfig['bannerAd']>(
    key: K,
    value: AdConfig['bannerAd'][K]
  ) => {
    const updated: AdConfig = {
      ...ads,
      bannerAd: {
        ...ads.bannerAd,
        [key]: value,
      },
    };
    setAds(updated);
    onUpdateGlobalAds(updated);
  };

  const handleCustomBannerChange = (field: string, value: string) => {
    const updated: AdConfig = {
      ...ads,
      bannerAd: {
        ...ads.bannerAd,
        customBanner: {
          ...ads.bannerAd.customBanner,
          [field]: value,
        },
      },
    };
    setAds(updated);
    onUpdateGlobalAds(updated);
  };

  const handleInterstitialChange = <K extends keyof AdConfig['interstitialAd']>(
    key: K,
    value: AdConfig['interstitialAd'][K]
  ) => {
    const updated: AdConfig = {
      ...ads,
      interstitialAd: {
        ...ads.interstitialAd,
        [key]: value,
      },
    };
    setAds(updated);
    onUpdateGlobalAds(updated);
  };

  const handleCustomInterstitialChange = (field: string, value: string) => {
    const updated: AdConfig = {
      ...ads,
      interstitialAd: {
        ...ads.interstitialAd,
        customInterstitial: {
          ...ads.interstitialAd.customInterstitial,
          [field]: value,
        },
      },
    };
    setAds(updated);
    onUpdateGlobalAds(updated);
  };

  const handleSyncAllApps = () => {
    storage.saveGlobalAds(ads, true);
    onUpdateGlobalAds(ads);
    setSyncedNotification(true);
    setTimeout(() => setSyncedNotification(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-amber-400 font-medium mb-1">
              <Megaphone className="w-3.5 h-3.5" />
              <span>CENTRAL REMOTE ADS & MONETIZATION HUB</span>
              <span aria-hidden="true">·</span>
              <span>LIVE CLOUD SYNC</span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Central Ads Control Room (Sabhi Apps par Ads Control)
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl leading-relaxed">
              Yahan se aap jo bhi ad set karenge, wo turant un sabhi Android APKs par dikhayi dega jo is website se banwaye gaye hain!
              Jab chahein naya ad lagayein, ad band karein, ya AdMob Unit ID badlein — bina naya APK banwaye.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={handleSyncAllApps}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-all shadow-md flex items-center gap-2 cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Sync Ads to All {apps.length} Apps</span>
            </button>
          </div>
        </div>

        {syncedNotification && (
          <div className="mt-4 p-3 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>Success! Sabhi {apps.length} converted apps par naye ads live sync ho chuke hain.</span>
          </div>
        )}
      </div>

      {/* Main Grid: Settings & Live Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Ad Settings */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
            {/* Master Toggle */}
            <div className="flex items-center justify-between p-4 rounded-xl bg-slate-950 border border-slate-800 mb-6">
              <div>
                <span className="text-xs font-bold text-white block">
                  Master Ads Network Status
                </span>
                <span className="text-[11px] text-slate-400">
                  Enable or disable ads across all converted APKs simultaneously.
                </span>
              </div>
              <button
                type="button"
                onClick={() => handleToggleGlobal(!ads.enabled)}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                  ads.enabled ? 'bg-emerald-600' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                    ads.enabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Provider Selector */}
            <div className="mb-6">
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Ad Network Provider
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const updated: AdConfig = { ...ads, provider: 'adsterra' };
                    setAds(updated);
                    onUpdateGlobalAds(updated);
                    setActiveTab('adsterra');
                  }}
                  className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                    ads.provider === 'adsterra'
                      ? 'bg-amber-500/10 border-amber-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <p className="text-xs font-bold text-amber-400">Adsterra (Recommended)</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Direct links, popunders & high CPM ads</p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const updated: AdConfig = { ...ads, provider: 'custom' };
                    setAds(updated);
                    onUpdateGlobalAds(updated);
                  }}
                  className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                    ads.provider === 'custom'
                      ? 'bg-indigo-600/10 border-indigo-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <p className="text-xs font-semibold">Custom Banner</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Your own promotions & affiliate links</p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const updated: AdConfig = { ...ads, provider: 'admob' };
                    setAds(updated);
                    onUpdateGlobalAds(updated);
                  }}
                  className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                    ads.provider === 'admob'
                      ? 'bg-indigo-600/10 border-indigo-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <p className="text-xs font-semibold">Google AdMob</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">AdMob banner & interstitials</p>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    const updated: AdConfig = { ...ads, provider: 'both' };
                    setAds(updated);
                    onUpdateGlobalAds(updated);
                  }}
                  className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                    ads.provider === 'both'
                      ? 'bg-indigo-600/10 border-indigo-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <p className="text-xs font-semibold">Hybrid All</p>
                  <p className="text-[10px] text-slate-400 mt-0.5">Adsterra + AdMob + Custom</p>
                </button>
              </div>
            </div>

            {/* Sub Tabs */}
            <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl mb-6 border border-slate-800">
              <button
                type="button"
                onClick={() => setActiveTab('adsterra')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
                  activeTab === 'adsterra' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Adsterra Ads</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('banner')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'banner' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Sticky Banner
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('interstitial')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'interstitial' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Interstitial / Popup
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('admob')}
                className={`flex-1 py-1.5 text-xs font-medium rounded-lg transition-colors cursor-pointer ${
                  activeTab === 'admob' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Google AdMob
              </button>
            </div>

            {/* Tab: Adsterra Configuration */}
            {activeTab === 'adsterra' && (
              <div className="space-y-4 animate-fade-in">
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200">
                  <div className="flex items-center gap-2 mb-1 text-amber-400 font-bold">
                    <Megaphone className="w-4 h-4" />
                    <span>Adsterra High CPM Ad Network Connected</span>
                  </div>
                  <p className="text-[11px] leading-relaxed">
                    Yahan aap apna Adsterra Direct Link aur Banner key daal sakte hain. Ye ad aapki website par bhi chalega
                    aur jo bhi user yahan se APK banwayega, uske app ke andar bhi Adsterra ke ads chalenge!
                  </p>
                </div>

                {/* Mandatory Ad-Gate before APK download */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-start justify-between gap-3">
                  <div>
                    <p className="text-xs font-bold text-white">
                      Mandatory Adsterra Ad Before APK Download (Jo APK banwayega usko ad dekhna padega)
                    </p>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      User jab "Download .APK File" dabayega, toh download shuru hone se pehle 5-second ka Adsterra sponsored ad dekhna anivarya hoga.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={ads.adsterra?.forceAdBeforeDownload ?? true}
                    onChange={(e) => handleAdsterraChange('forceAdBeforeDownload', e.target.checked)}
                    className="mt-1 rounded text-amber-500 cursor-pointer"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Adsterra Direct Link URL (Smart Direct Link)
                    </label>
                    <input
                      type="text"
                      value={ads.adsterra?.directLink || ''}
                      onChange={(e) => handleAdsterraChange('directLink', e.target.value)}
                      placeholder="https://www.profitablecpmrate.com/xyz123"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">High conversion direct offer link</p>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Ad Watch Countdown Timer
                    </label>
                    <select
                      value={ads.adsterra?.countdownSeconds || 5}
                      onChange={(e) => handleAdsterraChange('countdownSeconds', parseInt(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value={3}>3 Seconds (Quick)</option>
                      <option value={5}>5 Seconds (Recommended)</option>
                      <option value={8}>8 Seconds (Higher CPM)</option>
                      <option value={10}>10 Seconds (Maximum Revenue)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Adsterra Banner Zone Key
                    </label>
                    <input
                      type="text"
                      value={ads.adsterra?.bannerZoneKey || ''}
                      onChange={(e) => handleAdsterraChange('bannerZoneKey', e.target.value)}
                      placeholder="9e7a812bf1b402129c991a0c028a4911"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">Adsterra 320x50 / 728x90 Zone Key</p>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Adsterra Social Bar / Popunder Script URL
                    </label>
                    <input
                      type="text"
                      value={ads.adsterra?.socialBarScript || ''}
                      onChange={(e) => handleAdsterraChange('socialBarScript', e.target.value)}
                      placeholder="//pl22184920.profitablecpmrate.com/89/34/cd/xyz.js"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                    />
                    <p className="text-[10px] text-slate-500 mt-1">Social Bar script for website & APK webviews</p>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: Sticky Banner Ad */}
            {activeTab === 'banner' && (
              <div className="space-y-4 animate-fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div>
                    <p className="text-xs font-semibold text-white">Enable Bottom/Top Sticky Banner</p>
                    <p className="text-[11px] text-slate-400">Fixed ad bar inside the Android app.</p>
                  </div>
                  <input
                    type="checkbox"
                    checked={ads.bannerAd.enabled}
                    onChange={(e) => handleBannerChange('enabled', e.target.checked)}
                    className="rounded text-indigo-600"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Ad Headline / Title
                    </label>
                    <input
                      type="text"
                      value={ads.bannerAd.customBanner.title}
                      onChange={(e) => handleCustomBannerChange('title', e.target.value)}
                      placeholder="e.g. Special Offer 50% Off"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Ad Subtitle / Description
                    </label>
                    <input
                      type="text"
                      value={ads.bannerAd.customBanner.description}
                      onChange={(e) => handleCustomBannerChange('description', e.target.value)}
                      placeholder="e.g. Download the app today"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      CTA Button Text
                    </label>
                    <input
                      type="text"
                      value={ads.bannerAd.customBanner.ctaText}
                      onChange={(e) => handleCustomBannerChange('ctaText', e.target.value)}
                      placeholder="e.g. Claim Now"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Destination Link (Target URL)
                    </label>
                    <input
                      type="text"
                      value={ads.bannerAd.customBanner.targetUrl}
                      onChange={(e) => handleCustomBannerChange('targetUrl', e.target.value)}
                      placeholder="https://..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Banner Background Color
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={ads.bannerAd.customBanner.bgColor}
                        onChange={(e) => handleCustomBannerChange('bgColor', e.target.value)}
                        className="w-8 h-8 rounded cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={ads.bannerAd.customBanner.bgColor}
                        onChange={(e) => handleCustomBannerChange('bgColor', e.target.value)}
                        className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Position on Screen
                    </label>
                    <select
                      value={ads.bannerAd.position}
                      onChange={(e) =>
                        handleBannerChange('position', e.target.value as 'bottom' | 'top')
                      }
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value="bottom">Bottom of Screen (Recommended)</option>
                      <option value="top">Top of Screen</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: Interstitial Ad */}
            {activeTab === 'interstitial' && (
              <div className="space-y-4 animate-fade-in">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div>
                    <p className="text-xs font-semibold text-white">Enable Interstitial Popup Ad</p>
                    <p className="text-[11px] text-slate-400">
                      Full-screen popup shown after a specific number of page views.
                    </p>
                  </div>
                  <input
                    type="checkbox"
                    checked={ads.interstitialAd.enabled}
                    onChange={(e) => handleInterstitialChange('enabled', e.target.checked)}
                    className="rounded text-indigo-600"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Show on Every N Page Loads
                    </label>
                    <select
                      value={ads.interstitialAd.triggerOnPages}
                      onChange={(e) =>
                        handleInterstitialChange('triggerOnPages', parseInt(e.target.value))
                      }
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    >
                      <option value={2}>Every 2 page navigations</option>
                      <option value={3}>Every 3 page navigations (Optimal)</option>
                      <option value={5}>Every 5 page navigations</option>
                      <option value={10}>Every 10 page navigations (Light)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Popup Title
                    </label>
                    <input
                      type="text"
                      value={ads.interstitialAd.customInterstitial.title}
                      onChange={(e) => handleCustomInterstitialChange('title', e.target.value)}
                      placeholder="e.g. Sponsored Recommendation"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Popup Description
                  </label>
                  <textarea
                    rows={2}
                    value={ads.interstitialAd.customInterstitial.description}
                    onChange={(e) => handleCustomInterstitialChange('description', e.target.value)}
                    placeholder="Short description of the ad offer..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      CTA Button Text
                    </label>
                    <input
                      type="text"
                      value={ads.interstitialAd.customInterstitial.ctaText}
                      onChange={(e) => handleCustomInterstitialChange('ctaText', e.target.value)}
                      placeholder="e.g. Visit Offer"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-300 mb-1">
                      Target Link
                    </label>
                    <input
                      type="text"
                      value={ads.interstitialAd.customInterstitial.targetUrl}
                      onChange={(e) => handleCustomInterstitialChange('targetUrl', e.target.value)}
                      placeholder="https://..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Tab: Google AdMob */}
            {activeTab === 'admob' && (
              <div className="space-y-4 animate-fade-in">
                <div className="p-3 rounded-lg bg-indigo-950/40 border border-indigo-500/30 text-xs text-indigo-200">
                  <p className="font-semibold text-white mb-1">Google AdMob Integration Ready</p>
                  <p className="text-[11px] leading-relaxed">
                    Default values yahan Google ke Official Test Ad IDs diye gaye hain jisse policy violation na ho.
                    Jab aapka AdMob account approve ho jaye, tab aap apna real Ad Unit ID yahan daal sakte hain!
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    AdMob Banner Unit ID
                  </label>
                  <input
                    type="text"
                    value={ads.bannerAd.admobUnitId}
                    onChange={(e) => handleBannerChange('admobUnitId', e.target.value)}
                    placeholder="ca-app-pub-3940256099942544/6300978111"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Google Mobile Ads Banner Unit</p>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    AdMob Interstitial Unit ID
                  </label>
                  <input
                    type="text"
                    value={ads.interstitialAd.admobUnitId}
                    onChange={(e) => handleInterstitialChange('admobUnitId', e.target.value)}
                    placeholder="ca-app-pub-3940256099942544/1033173712"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white font-mono"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">Full-screen Interstitial Unit</p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Live Connected Apps & Active Banner Preview */}
        <div className="space-y-6">
          {/* Live Banner Preview Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-xs font-bold text-slate-300 mb-3 flex items-center justify-between">
              <span>Live Ad Banner Preview</span>
              <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded">
                As seen in APK
              </span>
            </h3>

            {/* Custom Banner Representation */}
            <div
              style={{ backgroundColor: ads.bannerAd.customBanner.bgColor || '#1e1b4b' }}
              className="p-3 rounded-xl border border-white/10 shadow-md text-white flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-2 truncate">
                <div className="w-8 h-8 rounded-lg bg-amber-400/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0 border border-amber-400/30">
                  AD
                </div>
                <div className="truncate">
                  <p className="text-xs font-bold truncate leading-tight">
                    {ads.bannerAd.customBanner.title || 'Special Promotion'}
                  </p>
                  <p className="text-[10px] text-indigo-200 truncate">
                    {ads.bannerAd.customBanner.description || 'Tap to explore.'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                className="px-3 py-1 rounded text-xs font-bold bg-white text-slate-900 hover:bg-slate-100 transition-colors whitespace-nowrap shrink-0"
              >
                {ads.bannerAd.customBanner.ctaText || 'Open'}
              </button>
            </div>
            <p className="text-[10px] text-slate-500 mt-2 text-center">
              This exact banner renders at the bottom of all {apps.length} converted apps.
            </p>
          </div>

          {/* Live Adsterra 300x250 Banner Unit Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-xs font-bold text-slate-300 mb-2 flex items-center justify-between">
              <span>Adsterra 300x250 Unit (Active)</span>
              <span className="text-[10px] font-mono text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded">
                ZONE 32124790
              </span>
            </h3>
            <AdsterraBanner300x250
              zoneKey={ads.adsterra?.bannerZoneKey || 'b35d45c32cd9d5ff4ec792d306d75bad'}
              scriptUrl={ads.adsterra?.bannerScriptUrl || 'https://brijmohan.org/22/b35d45c32cd9d5ff4ec792d306d75bad'}
              width={300}
              height={250}
            />
            <p className="text-[10px] text-slate-400 mt-2 text-center">
              Live Adsterra banner active on website & inside converted APKs.
            </p>
          </div>

          {/* Connected Apps Monitor */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h3 className="text-xs font-bold text-slate-300 mb-3 flex items-center justify-between">
              <span>Connected APKs Receiving Ads</span>
              <span className="text-[10px] font-mono text-emerald-400">
                {apps.length} ACTIVE
              </span>
            </h3>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {apps.map((app) => (
                <div
                  key={app.id}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-slate-700 flex items-center justify-between gap-2"
                >
                  <div className="truncate">
                    <p className="text-xs font-semibold text-white truncate">{app.name}</p>
                    <p className="text-[10px] text-slate-400 font-mono truncate">{app.packageName}</p>
                  </div>
                  <button
                    onClick={() => onSelectAppForPreview(app)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors shrink-0"
                    title="Preview this app in simulator"
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
