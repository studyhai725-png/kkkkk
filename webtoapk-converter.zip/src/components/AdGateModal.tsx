import React, { useState, useEffect } from 'react';
import { Megaphone, ExternalLink, Download, CheckCircle2, X, Sparkles, ShieldCheck } from 'lucide-react';
import { AdsterraConfig, AppConfig } from '../types/app';
import { AdsterraBanner300x250 } from './AdsterraAdUnit';

interface AdGateModalProps {
  app: AppConfig;
  adsterra?: AdsterraConfig;
  isOpen: boolean;
  onAdCompleted: () => void;
  onClose: () => void;
}

export const AdGateModal: React.FC<AdGateModalProps> = ({
  app,
  adsterra,
  isOpen,
  onAdCompleted,
  onClose,
}) => {
  const countdownDuration = adsterra?.countdownSeconds || 5;
  const [secondsLeft, setSecondsLeft] = useState(countdownDuration);
  const [hasVisitedAd, setHasVisitedAd] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setSecondsLeft(countdownDuration);
      return;
    }

    setSecondsLeft(countdownDuration);
    const interval = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isOpen, countdownDuration]);

  if (!isOpen) return null;

  const handleVisitDirectLink = () => {
    setHasVisitedAd(true);
    const link = adsterra?.directLink || 'https://www.profitablecpmrate.com/d87f91a92e104';
    window.open(link, '_blank', 'noopener,noreferrer');
  };

  const isReady = secondsLeft === 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 shadow-2xl relative overflow-hidden text-center">
        {/* Top Header */}
        <div className="flex items-center justify-between mb-3 text-slate-400">
          <div className="flex items-center gap-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2.5 py-0.5 rounded-full text-[11px] font-semibold">
            <Megaphone className="w-3.5 h-3.5" />
            <span>Adsterra Sponsored Network</span>
          </div>

          {isReady ? (
            <button
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          ) : (
            <span className="text-[11px] font-mono text-slate-400">
              Skip in {secondsLeft}s
            </span>
          )}
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-white mb-1">
          APK Generation in Progress
        </h3>
        <p className="text-xs text-slate-400 mb-4 leading-relaxed">
          Free APK build service ko support karne ke liye niche diya gaya sponsor ad dekhein.
          Timer khatam hote hi aapka <strong>{app.name}.apk</strong> apne aap download ho jayega!
        </p>

        {/* Adsterra Interactive 300x250 Banner & Direct Link */}
        <AdsterraBanner300x250
          zoneKey={adsterra?.bannerZoneKey || 'b35d45c32cd9d5ff4ec792d306d75bad'}
          scriptUrl={adsterra?.bannerScriptUrl || 'https://brijmohan.org/22/b35d45c32cd9d5ff4ec792d306d75bad'}
          width={300}
          height={250}
        />

        <div className="mb-4">
          <button
            onClick={handleVisitDirectLink}
            className="w-full py-2 px-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-md cursor-pointer"
          >
            <span>Visit Sponsored Partner Link</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Action Button: Download when timer reaches 0 */}
        <div className="space-y-2">
          {isReady ? (
            <button
              onClick={onAdCompleted}
              className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-all shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer animate-pulse"
            >
              <Download className="w-4 h-4" />
              <span>Download {app.name}.apk Now</span>
            </button>
          ) : (
            <div className="w-full py-3 px-4 rounded-xl bg-slate-800 text-slate-400 font-semibold text-xs flex items-center justify-center gap-2">
              <div className="w-4 h-4 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
              <span>Please wait {secondsLeft} seconds to unlock APK...</span>
            </div>
          )}

          <p className="text-[10px] text-slate-500">
            Powered by Adsterra Ads Core · Synchronized with all converted APKs
          </p>
        </div>
      </div>
    </div>
  );
};
