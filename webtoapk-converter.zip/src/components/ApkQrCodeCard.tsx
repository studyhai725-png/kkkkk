import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { QrCode, Download, Copy, Check, ExternalLink, Smartphone, Share2, Sparkles } from 'lucide-react';
import { AppConfig } from '../types/app';

interface ApkQrCodeCardProps {
  app: AppConfig;
  onDownloadDirectApk?: () => void;
  onDownloadZip?: () => void;
}

export const ApkQrCodeCard: React.FC<ApkQrCodeCardProps> = ({
  app,
  onDownloadDirectApk,
  onDownloadZip,
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [activeMode, setActiveMode] = useState<'install' | 'website'>('install');

  const origin = typeof window !== 'undefined' ? window.location.origin : 'https://ais-dev-zdzf6osjcmgrxxnqvdmmve-324190308038.asia-northeast1.run.app';
  const installUrl = `${origin}/?install=${app.id}`;
  const targetUrl = app.url || 'https://google.com';

  const currentQrUrl = activeMode === 'install' ? installUrl : targetUrl;

  useEffect(() => {
    let isMounted = true;
    QRCode.toDataURL(currentQrUrl, {
      width: 260,
      margin: 2,
      color: {
        dark: '#090d16',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'H',
    })
      .then((url) => {
        if (isMounted) setQrDataUrl(url);
      })
      .catch((err) => {
        console.error('QR code generation failed:', err);
      });

    return () => {
      isMounted = false;
    };
  }, [currentQrUrl]);

  const handleCopy = () => {
    navigator.clipboard.writeText(currentQrUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadQrPng = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    const cleanName = (app.name || 'App').replace(/[^a-zA-Z0-9_-]/g, '_');
    a.download = `${cleanName}_Install_QRCode.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 text-center shadow-inner relative overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2 text-xs font-bold text-indigo-400">
          <QrCode className="w-4 h-4" />
          <span>SCAN TO INSTALL ON ANDROID</span>
        </div>
        <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-semibold">
          Mobile QR Code
        </span>
      </div>

      <p className="text-xs text-slate-300 mb-3 text-left leading-relaxed">
        Apne Android phone ke <strong>Camera</strong> ya <strong>Google Lens</strong> se scan karein aur seedha apne phone me APK install karein!
      </p>

      {/* QR Code Mode Switcher */}
      <div className="flex rounded-xl bg-slate-900 p-1 mb-4 border border-slate-800 text-xs">
        <button
          type="button"
          onClick={() => setActiveMode('install')}
          className={`flex-1 py-1.5 px-2 rounded-lg font-semibold transition-all cursor-pointer ${
            activeMode === 'install'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          📱 Direct APK Installer
        </button>
        <button
          type="button"
          onClick={() => setActiveMode('website')}
          className={`flex-1 py-1.5 px-2 rounded-lg font-semibold transition-all cursor-pointer ${
            activeMode === 'website'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          🌐 Target Website URL
        </button>
      </div>

      {/* QR Code Container */}
      <div className="relative inline-block p-3.5 bg-white rounded-2xl shadow-xl shadow-indigo-950/40 border-2 border-indigo-500/30 mb-3">
        {qrDataUrl ? (
          <img
            src={qrDataUrl}
            alt={`QR code for ${app.name}`}
            className="w-44 h-44 sm:w-48 sm:h-48 rounded-lg mx-auto block"
          />
        ) : (
          <div className="w-44 h-44 sm:w-48 sm:h-48 flex items-center justify-center text-slate-400 text-xs">
            Generating QR...
          </div>
        )}
        <div className="mt-2 text-center">
          <span className="text-[10px] font-bold text-slate-800 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
            {app.name} · v{app.versionName}
          </span>
        </div>
      </div>

      {/* Link display & quick copy */}
      <div className="mb-3 p-2 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2 text-left">
        <span className="text-[11px] text-slate-400 font-mono truncate select-all">
          {currentQrUrl}
        </span>
        <button
          type="button"
          onClick={handleCopy}
          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer shrink-0"
          title="Copy Link"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
        </button>
      </div>

      {/* Actions: Download QR PNG & Copy Link */}
      <div className="grid grid-cols-2 gap-2 mb-3">
        <button
          type="button"
          onClick={handleDownloadQrPng}
          className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
        >
          <Download className="w-3.5 h-3.5 text-indigo-400" />
          <span>Save QR (PNG)</span>
        </button>

        <button
          type="button"
          onClick={handleCopy}
          className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer border border-slate-700"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5 text-indigo-400" />}
          <span>{copied ? 'Link Copied!' : 'Copy Link'}</span>
        </button>
      </div>

      {/* Steps callout */}
      <div className="p-2.5 rounded-xl bg-indigo-950/40 border border-indigo-500/30 text-left text-[11px] text-indigo-200 flex items-start gap-2">
        <Smartphone className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <div>
          <strong>Mobile Scan Tip:</strong> Apne phone ka camera scan karke open karein. Website automatically Adsterra ads view kara kar seedha aapke phone me APK download shuru kar degi!
        </div>
      </div>
    </div>
  );
};
