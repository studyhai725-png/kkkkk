import React, { useState } from 'react';
import {
  Smartphone,
  Download,
  Eye,
  ExternalLink,
  Edit2,
  Trash2,
  Radio,
  AlertTriangle,
  Bell,
  Check,
  X,
  Plus,
  RefreshCw,
  FileCode,
} from 'lucide-react';
import { AppConfig } from '../types/app';
import { storage } from '../services/storage';

interface MyAppsListProps {
  apps: AppConfig[];
  onSelectAppForPreview: (app: AppConfig) => void;
  onDownloadDirectApk: (app: AppConfig) => void;
  onDownloadZip: (app: AppConfig) => void;
  onNewApp: () => void;
  onRefreshApps: () => void;
}

export const MyAppsList: React.FC<MyAppsListProps> = ({
  apps,
  onSelectAppForPreview,
  onDownloadDirectApk,
  onDownloadZip,
  onNewApp,
  onRefreshApps,
}) => {
  const [editingAppId, setEditingAppId] = useState<string | null>(null);
  const [editedUrl, setEditedUrl] = useState('');
  const [editedAnnouncement, setEditedAnnouncement] = useState('');
  const [announcementModalApp, setAnnouncementModalApp] = useState<AppConfig | null>(null);
  const [successToast, setSuccessToast] = useState('');

  const handleStartEdit = (app: AppConfig) => {
    setEditingAppId(app.id);
    setEditedUrl(app.remoteSync.currentUrl || app.url);
  };

  const handleSaveRemoteUrl = (app: AppConfig) => {
    let clean = editedUrl.trim();
    if (clean && !clean.startsWith('http')) {
      clean = 'https://' + clean;
    }
    const updated: AppConfig = {
      ...app,
      url: clean,
      remoteSync: {
        ...app.remoteSync,
        currentUrl: clean,
        lastSyncedAt: new Date().toISOString(),
      },
      updatedAt: new Date().toISOString(),
    };
    storage.saveApp(updated);
    setEditingAppId(null);
    onRefreshApps();
    setSuccessToast(`Remote URL updated for ${app.name}! APK will now load this URL automatically.`);
    setTimeout(() => setSuccessToast(''), 4000);
  };

  const handleToggleMaintenance = (app: AppConfig) => {
    const updated: AppConfig = {
      ...app,
      remoteSync: {
        ...app.remoteSync,
        maintenanceMode: !app.remoteSync.maintenanceMode,
        lastSyncedAt: new Date().toISOString(),
      },
      updatedAt: new Date().toISOString(),
    };
    storage.saveApp(updated);
    onRefreshApps();
    setSuccessToast(
      `Maintenance mode for ${app.name} is now ${updated.remoteSync.maintenanceMode ? 'ENABLED' : 'DISABLED'}.`
    );
    setTimeout(() => setSuccessToast(''), 4000);
  };

  const handleSendAnnouncement = (app: AppConfig) => {
    const updated: AppConfig = {
      ...app,
      remoteSync: {
        ...app.remoteSync,
        announcement: {
          ...app.remoteSync.announcement,
          enabled: !!editedAnnouncement.trim(),
          text: editedAnnouncement.trim(),
        },
        lastSyncedAt: new Date().toISOString(),
      },
      updatedAt: new Date().toISOString(),
    };
    storage.saveApp(updated);
    setAnnouncementModalApp(null);
    setEditedAnnouncement('');
    onRefreshApps();
    setSuccessToast(`Announcement sent directly to ${app.name}!`);
    setTimeout(() => setSuccessToast(''), 4000);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete ${name}?`)) {
      storage.deleteApp(id);
      onRefreshApps();
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div>
          <div className="flex items-center gap-2 text-xs text-indigo-400 font-medium mb-1">
            <span>MY CONVERTED APPS</span>
            <span aria-hidden="true">·</span>
            <span>CLOUD SYNC CONNECTED</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight">
            Aapke Sabhi Banwaye Gaye Apps ({apps.length})
          </h2>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Ye sabhi APKs aapki website se hamesha connected rehte hain. Yahan se aap bina naya APK banwaye
            kisi bhi app ka URL badal sakte hain, notice bhej sakte hain, ya unka Android project ZIP download kar sakte hain.
          </p>
        </div>

        <button
          onClick={onNewApp}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-all shadow-md flex items-center gap-2 whitespace-nowrap cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Convert Another Website</span>
        </button>
      </div>

      {successToast && (
        <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{successToast}</span>
        </div>
      )}

      {/* Apps Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {apps.map((app) => (
          <div
            key={app.id}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col justify-between hover:border-slate-700 transition-colors"
          >
            <div>
              {/* App Card Header */}
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div
                    style={{ backgroundColor: app.themeColor }}
                    className="w-11 h-11 rounded-xl flex items-center justify-center text-white font-bold text-base shadow-sm shrink-0"
                  >
                    {app.name.charAt(0) || 'A'}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white leading-tight">{app.name}</h3>
                    <p className="text-[11px] text-slate-400 font-mono">{app.packageName}</p>
                    <div className="flex items-center gap-2 mt-1 text-[10px] text-slate-500">
                      <span>v{app.versionName}</span>
                      <span>·</span>
                      <span className="flex items-center gap-1 text-emerald-400">
                        <Radio className="w-2.5 h-2.5" />
                        <span>Cloud Synced</span>
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onSelectAppForPreview(app)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                    title="Open in Simulator"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => handleDelete(app.id, app.name)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/40 text-slate-400 hover:text-rose-400 transition-colors"
                    title="Delete App"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Target URL Row with Quick Remote Editing */}
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 mb-3">
                <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                  <span className="font-semibold text-slate-300">Live Destination URL:</span>
                  {editingAppId !== app.id && (
                    <button
                      onClick={() => handleStartEdit(app)}
                      className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 text-[10px] cursor-pointer"
                    >
                      <Edit2 className="w-3 h-3" />
                      <span>Change URL Remotely</span>
                    </button>
                  )}
                </div>

                {editingAppId === app.id ? (
                  <div className="flex items-center gap-2 mt-1">
                    <input
                      type="text"
                      value={editedUrl}
                      onChange={(e) => setEditedUrl(e.target.value)}
                      className="flex-1 bg-slate-900 border border-slate-700 rounded px-2.5 py-1 text-xs text-white font-mono"
                    />
                    <button
                      onClick={() => handleSaveRemoteUrl(app)}
                      className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-semibold"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditingAppId(null)}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-indigo-300 font-mono truncate max-w-[260px]">
                      {app.remoteSync.currentUrl || app.url}
                    </span>
                    <a
                      href={app.remoteSync.currentUrl || app.url}
                      target="_blank"
                      rel="noreferrer"
                      className="text-slate-500 hover:text-slate-300"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                )}
              </div>

              {/* Remote Cloud Actions */}
              <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                <button
                  onClick={() => handleToggleMaintenance(app)}
                  className={`p-2 rounded-lg border text-left transition-colors flex items-center justify-between cursor-pointer ${
                    app.remoteSync.maintenanceMode
                      ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <span className="text-[11px] font-medium">Maintenance Mode</span>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                      app.remoteSync.maintenanceMode
                        ? 'bg-amber-500/20 text-amber-300'
                        : 'bg-slate-800 text-slate-500'
                    }`}
                  >
                    {app.remoteSync.maintenanceMode ? 'ON' : 'OFF'}
                  </span>
                </button>

                <button
                  onClick={() => {
                    setAnnouncementModalApp(app);
                    setEditedAnnouncement(app.remoteSync.announcement.text || '');
                  }}
                  className="p-2 rounded-lg border border-slate-800 bg-slate-950 hover:border-slate-700 text-slate-300 flex items-center justify-between cursor-pointer transition-colors"
                >
                  <span className="text-[11px] font-medium">Push Notice</span>
                  <Bell className="w-3.5 h-3.5 text-indigo-400" />
                </button>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-[10px] text-slate-500">
                Ads Synced: {app.remoteSync.ads.enabled ? 'Yes (Active)' : 'Disabled'}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onDownloadZip(app)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors border border-slate-700 flex items-center gap-1 cursor-pointer"
                  title="Download full project folder for Android Studio"
                >
                  <FileCode className="w-3 h-3 text-slate-400" />
                  <span>ZIP</span>
                </button>

                <button
                  onClick={() => onDownloadDirectApk(app)}
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm shadow-emerald-600/30 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .APK</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Push Announcement Modal */}
      {announcementModalApp && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Bell className="w-4 h-4 text-indigo-400" />
                <span>Push Notice to {announcementModalApp.name}</span>
              </h3>
              <button
                onClick={() => setAnnouncementModalApp(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-3">
              Ye message seedha users ke Android app ke top par ek red announcement bar me dikhega.
            </p>

            <textarea
              rows={3}
              value={editedAnnouncement}
              onChange={(e) => setEditedAnnouncement(e.target.value)}
              placeholder="e.g. Flash Sale Live! Flat 50% discount on all orders today."
              className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-xs text-white placeholder-slate-500 mb-4 focus:outline-hidden focus:border-indigo-500"
            />

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setAnnouncementModalApp(null)}
                className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSendAnnouncement(announcementModalApp)}
                className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition-colors"
              >
                Broadcast to App
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
