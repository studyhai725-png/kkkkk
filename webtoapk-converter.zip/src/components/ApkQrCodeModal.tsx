import React from 'react';
import { X, Smartphone } from 'lucide-react';
import { AppConfig } from '../types/app';
import { ApkQrCodeCard } from './ApkQrCodeCard';

interface ApkQrCodeModalProps {
  app: AppConfig | null;
  isOpen: boolean;
  onClose: () => void;
  onDownloadDirectApk?: (app: AppConfig) => void;
  onDownloadZip?: (app: AppConfig) => void;
}

export const ApkQrCodeModal: React.FC<ApkQrCodeModalProps> = ({
  app,
  isOpen,
  onClose,
  onDownloadDirectApk,
  onDownloadZip,
}) => {
  if (!isOpen || !app) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 animate-fade-in overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700 rounded-3xl w-full max-w-md p-6 shadow-2xl relative my-8">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white cursor-pointer z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-4 text-left">
          <div className="flex items-center gap-2 text-indigo-400 text-xs font-semibold mb-1">
            <Smartphone className="w-3.5 h-3.5" />
            <span>DIRECT PHONE INSTALLER</span>
          </div>
          <h3 className="text-lg font-bold text-white tracking-tight">
            Scan QR Code to Install on Phone
          </h3>
          <p className="text-xs text-slate-400">
            {app.name} ({app.packageName})
          </p>
        </div>

        <ApkQrCodeCard
          app={app}
          onDownloadDirectApk={() => onDownloadDirectApk?.(app)}
          onDownloadZip={() => onDownloadZip?.(app)}
        />

        <div className="mt-4 pt-3 border-t border-slate-800 text-center">
          <button
            onClick={onClose}
            className="w-full py-2 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
