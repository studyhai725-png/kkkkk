export interface AdsterraConfig {
  enabled: boolean;
  directLink: string; // e.g. Adsterra Smart Direct Link
  bannerZoneKey: string; // Adsterra 320x50 or 728x90 Zone Key
  bannerScriptUrl: string; // Adsterra invoke.js url
  socialBarScript: string; // Adsterra social bar / in-page push script
  popunderUrl: string; // Popunder trigger url
  forceAdBeforeDownload: boolean; // Compulsory ad watch before downloading APK
  countdownSeconds: number; // Delay timer before download begins (e.g. 5s)
}

export interface AdConfig {
  enabled: boolean;
  provider: 'adsterra' | 'custom' | 'admob' | 'both' | 'all';
  adsterra: AdsterraConfig;
  bannerAd: {
    enabled: boolean;
    position: 'bottom' | 'top';
    customBanner: {
      title: string;
      description: string;
      imageUrl?: string;
      ctaText: string;
      targetUrl: string;
      bgColor: string;
      textColor: string;
    };
    admobUnitId: string;
  };
  interstitialAd: {
    enabled: boolean;
    intervalMinutes: number; // how often to trigger
    triggerOnPages: number; // e.g. every 3 page loads
    customInterstitial: {
      title: string;
      description: string;
      imageUrl?: string;
      ctaText: string;
      targetUrl: string;
    };
    admobUnitId: string;
  };
}

export interface RemoteSyncConfig {
  syncEnabled: boolean;
  currentUrl: string;
  maintenanceMode: boolean;
  maintenanceMessage: string;
  announcement: {
    enabled: boolean;
    id: string;
    text: string;
    actionUrl?: string;
    type: 'info' | 'warning' | 'promo';
  };
  ads: AdConfig;
  lastSyncedAt: string;
}

export interface AppPermissions {
  internet: boolean;
  camera: boolean;
  storage: boolean;
  geolocation: boolean;
  notifications: boolean;
  microphone: boolean;
}

export interface AppConfig {
  id: string;
  name: string;
  packageName: string;
  versionName: string;
  versionCode: number;
  url: string;
  iconDataUrl: string; // Base64 or URL
  themeColor: string;
  splashBgColor: string;
  splashDurationMs: number;
  pullToRefresh: boolean;
  showNavigationControls: boolean;
  zoomControls: boolean;
  offlineSupport: boolean;
  enableDownloadManager: boolean;
  enableFileUploads: boolean;
  permissions: AppPermissions;
  remoteSync: RemoteSyncConfig;
  createdAt: string;
  updatedAt: string;
}
